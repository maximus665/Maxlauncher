const {test}=require('node:test');
const assert=require('node:assert/strict');
const crypto=require('node:crypto');
const fs=require('node:fs/promises');
const os=require('node:os');
const path=require('node:path');
const {APP_ID,releaseUrl,verifyManifest,compareVersions}=require('../src/main/services/update-policy.cjs');
const {LauncherUpdates,githubFetch}=require('../src/main/services/launcher-updates.cjs');
const repository='maximus665/Maxlauncher', now=Date.parse('2026-10-11T12:00:00Z');
const {privateKey,publicKey}=crypto.generateKeyPairSync('ed25519');
const publicPem=publicKey.export({type:'spki',format:'pem'});
const installer=Buffer.from('TEST-ONLY-INSTALLER-NOT-EXECUTABLE');
const base={schemaVersion:1,appId:APP_ID,repository,platform:'win32-x64',version:'0.3.1',url:releaseUrl(repository,'0.3.1','Max-Launcher-Setup-0.3.1.exe'),size:installer.length,sha512:crypto.createHash('sha512').update(installer).digest('hex'),issuedAt:new Date(now).toISOString(),expiresAt:new Date(now+86400000).toISOString()};
function signed(manifest=base,key=privateKey){const bytes=Buffer.from(JSON.stringify(manifest));return {bytes,signature:crypto.sign(null,bytes,key).toString('base64')};}
function verify(record,options={}){return verifyManifest(record.bytes,record.signature,publicPem,{repository,currentVersion:'0.3.0',now,...options});}
test('real Ed25519 signature is required; tampering and unknown keys fail closed',()=>{
 const good=signed();assert.equal(verify(good).version,'0.3.1');
 assert.throws(()=>verify({...good,signature:''}));
 assert.throws(()=>verify({...good,bytes:Buffer.from(JSON.stringify({...base,sha512:'a'.repeat(128)}))}));
 assert.throws(()=>verify(signed(base,crypto.generateKeyPairSync('ed25519').privateKey)));
});
test('policy rejects expired, future, rollback, wrong platform and arbitrary executable URLs',()=>{
 for(const change of [{expiresAt:new Date(now-1).toISOString()},{issuedAt:new Date(now+600000).toISOString()},{version:'0.2.9'},{platform:'linux-x64'},{appId:'other.app'},{url:'https://attacker.example/payload.exe'},{size:600*1024*1024},{sha512:'not-a-hash'},{version:'1.0.0-beta'}])assert.throws(()=>verify(signed({...base,...change})));
 assert.throws(()=>verify(signed(),{highestVersion:'0.4.0'}));
 assert.equal(compareVersions('0.10.0','0.9.9'),1);
});
test('redirects to HTTP, credential URLs and unapproved hosts are rejected',async()=>{
 for(const url of ['http://github.com/file','https://user:secret@github.com/file','https://evil.example/file'])await assert.rejects(githubFetch(url,async()=>{throw Error('must not fetch')}));
 await assert.rejects(githubFetch('https://github.com/file',async()=>new Response(null,{status:302,headers:{location:'https://evil.example/file'}})),/Origen/);
});
test('GitHub release metadata uses JSON Accept, preventing HTTP 415',async()=>{
 for(const route of ['latest','tags/v0.3.1']){
  const response=await githubFetch(`https://api.github.com/repos/${repository}/releases/${route}`,async(_url,options)=>{
   if(options.headers.Accept!=='application/vnd.github+json')return new Response(null,{status:415});
   return Response.json({tag_name:'v0.3.1'});
  });
  assert.equal(response.status,200);
 }
});
test('release assets and redirected asset hosts retain binary Accept',async()=>{
 const seen=[];
 await githubFetch(releaseUrl(repository,'0.3.1','maxlauncher-update.json'),async(url,options)=>{
  seen.push({url,accept:options.headers.Accept});
  return seen.length===1?new Response(null,{status:302,headers:{location:'https://release-assets.githubusercontent.com/test'}}):new Response('{}');
 });
 assert.equal(seen.length,2);assert.ok(seen.every(item=>item.accept==='application/octet-stream'));
});
async function fixture(run,{manifest=base,payload=installer,busy=false,installed=true,signatureKey=privateKey}={}){
 const dir=await fs.mkdtemp(path.join(os.tmpdir(),'maxlauncher-update-test-'));
 const record=signed(manifest,signatureKey);let runs=0,quits=0,fetches=0;
 const service=new LauncherUpdates({platform:'win32-x64',repository,publicKey:publicPem,currentVersion:'0.3.0',userData:()=>dir,installed,gameRunning:()=>busy,now:()=>now,runInstaller:async()=>{runs++},quit:()=>{quits++},fetcher:async url=>{
  fetches++;
  if(url.includes('api.github.com'))return Response.json({tag_name:'v0.3.1',draft:false,prerelease:false});
  if(url.endsWith('.json'))return new Response(record.bytes);
  if(url.endsWith('.sig'))return new Response(record.signature);
  return new Response(payload);
 }});
 try{await run({service,dir,calls:()=>({runs,quits,fetches})});}finally{await fs.rm(dir,{recursive:true,force:true});}
}
test('verified update downloads once and installation requires explicit call',async()=>fixture(async({service,calls})=>{
 assert.equal((await service.check()).phase,'available');
 assert.equal((await service.download()).phase,'ready');assert.equal(calls().runs,0);
 await service.install();assert.equal(calls().runs,1);assert.equal(calls().quits,1);
 await assert.rejects(service.install());assert.equal(calls().runs,1);
}));
test('corrupted installer is deleted without executing anything',async()=>fixture(async({service,dir,calls})=>{
 await service.check();assert.equal((await service.download()).phase,'error');
 assert.equal(calls().runs,0);assert.equal((await fs.readdir(path.join(dir,'updates'))).some(name=>name.endsWith('.exe')),false);
},{payload:Buffer.from('tampered')}));
test('wrong signature never reaches installer download',async()=>fixture(async({service,calls})=>{
 assert.equal((await service.check()).phase,'error');await service.download();assert.equal(calls().fetches,3);assert.equal(calls().runs,0);
},{signatureKey:crypto.generateKeyPairSync('ed25519').privateKey}));
test('installer is rehashed before execution, preventing cached-file replacement',async()=>fixture(async({service,calls})=>{
 await service.check();await service.download();await fs.writeFile(service.file,Buffer.alloc(installer.length));
 await assert.rejects(service.install());assert.equal(calls().runs,0);
}));
test('running game and unpacked builds cannot install updates',async()=>{
 for(const options of [{busy:true},{installed:false}])await fixture(async({service,calls})=>{
  await service.check();await service.download();await assert.rejects(service.install());assert.equal(calls().runs,0);
 },options);
});
test('simultaneous checks are deduplicated and highest accepted version persists',async()=>fixture(async({service,dir})=>{
 await Promise.all([service.check(),service.check(),service.check()]);
 assert.equal(JSON.parse(await fs.readFile(path.join(dir,'updates/highest-version.json'),'utf8')).version,'0.3.1');
}));
test('interrupted stream is removed and automatically retried from zero',async()=>fixture(async({service,dir,calls})=>{
 await service.check();const original=service.fetcher;let time=now;service.now=()=>time;
 service.fetcher=async()=>new Response(new ReadableStream({start(controller){controller.enqueue(installer.subarray(0,5));controller.error(new TypeError('connection lost'));}}));
 assert.equal((await service.download()).phase,'waiting');
 assert.equal((await fs.readdir(path.join(dir,'updates'))).some(name=>name.endsWith('.exe')),false);
 assert.equal(calls().runs,0);service.fetcher=original;time+=60000;
 assert.equal((await service.retry()).phase,'ready');assert.equal(calls().runs,0);
}));
