const {test}=require('node:test');
const assert=require('node:assert/strict');
const Module=require('node:module');
const original=Module._load;
Module._load=function(name,...args){if(name==='electron')return {safeStorage:{isEncryptionAvailable:()=>false}};return original.call(this,name,...args)};
const {SupabaseService}=require('../src/main/services/supabase-service.cjs');
Module._load=original;
const id='00000000-0000-0000-0000-000000000001';
const image='https://example.supabase.co/storage/v1/object/public/instance-images/u/image.png';
function service(role='owner'){
 const s=new SupabaseService(()=>'.');s.me=async()=>({profile:{role},user:{id}});s.config=async()=>({url:'https://example.supabase.co',publishableKey:'public-test'});s.activeSession=async()=>({access_token:'test'});return s;
}
test('ordinary accounts cannot create, edit, delete or change permissions',async()=>{
 const s=service('player');s.request=async()=>{throw Error('Unexpected request')};
 await assert.rejects(s.createInstance({}),/Solo/);await assert.rejects(s.updateInstance(id,{}),/permiso/);await assert.rejects(s.deleteInstance(id),/permiso/);await assert.rejects(s.managePermissions({}),/dueño/);
});
test('players cannot moderate; own account and owner role remain protected',async()=>{
 await assert.rejects(service('player').manageBan({userId:id,banned:true}),/dueño/);
 const s=service();s.request=async()=>{throw Error('Unexpected write')};
 await assert.rejects(s.manageBan({userId:id,banned:true}),/protegida/);
 await assert.rejects(s.managePermissions({userId:id,role:'admin',verified:true}),/quitarte/);
});
test('ban and unban use authenticated RPC and validate input',async()=>{
 const s=service(),other='00000000-0000-0000-0000-000000000002';let calls=[];
 s.request=async(route,options,auth)=>{calls.push({route,body:JSON.parse(options.body),auth});return {is_banned:true}};
 for(const banned of [true,false])await s.manageBan({userId:other,banned,reason:'  Moderación  '});
 assert.ok(calls.every(c=>c.auth && c.route==='/rest/v1/rpc/moderate_launcher_user'));assert.equal(calls[0].body.public_reason,'Moderación');assert.equal(calls[1].body.ban_enabled,false);
 await assert.rejects(s.manageBan({userId:other,banned:'true'}),/válidos/);
 await assert.rejects(s.manageBan({userId:other,banned:true,reason:'a'.repeat(501)}),/válidos/);
});
test('temporary bans validate time before sending authenticated moderation RPC',async()=>{
 const s=service('moderator'),other='00000000-0000-0000-0000-000000000002';let body;
 s.request=async(_r,o)=>{body=JSON.parse(o.body);return {}};
 const expiresAt=new Date(Date.now()+3600000).toISOString();await s.manageBan({userId:other,banned:true,reason:'Normas',expiresAt});assert.equal(body.expires_at,expiresAt);
 for(const expiry of ['invalid',new Date(Date.now()-60000).toISOString(),new Date(Date.now()+366*86400000).toISOString()])await assert.rejects(s.manageBan({userId:other,banned:true,reason:'Normas',expiresAt:expiry}),/Duración/);
});
test('public banned profile does not request published instances',async()=>{
 const s=service();let calls=0;s.request=async route=>{calls++;assert.equal(route,'/rest/v1/rpc/launcher_public_profiles');return [{id,is_banned:true,avatar_url:null,banner_url:null}]};
 const result=await s.userDetail(id);assert.equal(result.profile.is_banned,true);assert.deepEqual(result.instances,[]);assert.equal(calls,1);
});
test('banned account clears session and never returns authenticated profile',async()=>{
 const s=service();delete s.me;let cleared=0;s.clearSession=async()=>cleared++;
 s.activeSession=async()=>({user:{id},access_token:'test'});s.request=async()=>[{id,is_banned:true,role:'player'}];
 await assert.rejects(s.me(),/Cuenta suspendida/);assert.equal(cleared,1);
});
test('schedule requires end after start',()=>assert.throws(()=>service().instancePayload({availability_start:'2026-10-10',availability_end:'2026-10-09'}),/posterior/));
test('published announcements can be saved without a download link',async()=>{
 const s=service();s.request=async(_route,options)=>[JSON.parse(options.body)];
 const row=await s.createInstance({slug:'announcement',name:'New event',is_published:true});
 assert.equal(row.manifest_url,null);assert.equal(row.package_url,null);assert.equal(row.is_published,true);
});
test('package links require a valid hash and HTTPS',()=>{
 assert.throws(()=>service().instancePayload({package_url:'https://example.com/a.zip'}),/SHA/);
 assert.throws(()=>service().instancePayload({package_url:'http://example.com/a.zip',package_sha256:'a'.repeat(64)}),/HTTPS/);
 assert.equal(service().instancePayload({package_url:'https://example.com/a.zip',package_sha256:'a'.repeat(64)}).package_sha256,'a'.repeat(64));
});
test('deletion removes database row before cleaning unique media',async()=>{
 const s=service(),actions=[];s.request=async(route,opts)=>{if(opts.method==='DELETE'){actions.push('row');return null}return [{image_url:image,banner_url:image}]};s.deleteManagedImage=async url=>{assert.equal(url,image);actions.push('image')};
 assert.deepEqual(await s.deleteInstance(id),{deleted:true,cleanupPending:false});assert.deepEqual(actions,['row','image']);
});
test('failed storage cleanup is reported after successful row deletion',async()=>{
 const s=service();s.request=async(_r,o)=>o.method==='DELETE'?null:[{image_url:image}];s.deleteManagedImage=async()=>{throw Error('Unavailable')};assert.equal((await s.deleteInstance(id)).cleanupPending,true);
});
test('shared or external images are preserved',async()=>{
 const s=service();s.request=async()=>true;await s.deleteManagedImage(image);await s.deleteManagedImage('https://other.example/image.png');
});
test('editing preserves referenced media and cleans replaced images only',async()=>{
 const s=service(),cleaned=[];const input={slug:'event',name:'Event',manifest_url:'https://example.com/manifest.json',image_url:image,banner_url:'https://example.com/new.png'};
 s.request=async(_r,o)=>o.method==='PATCH'?[JSON.parse(o.body)]:[{image_url:image,banner_url:'https://example.com/old.png'}];s.deleteManagedImage=async url=>cleaned.push(url);
 const result=await s.updateInstance(id,input);assert.equal(result.image_url,image);assert.deepEqual(cleaned,['https://example.com/old.png']);
});
