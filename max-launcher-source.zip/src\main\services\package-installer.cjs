const fs=require('fs/promises');
const fssync=require('fs');
const path=require('path');
const crypto=require('crypto');
const {pipeline}=require('stream/promises');
const {Readable,Transform}=require('stream');
const yauzl=require('yauzl');
function safeTarget(root,name){
 if(typeof name!=='string'||!name||name.includes('\\')||name.split('/').some(part=>part==='..'||part.includes(':')||/[. ]$/.test(part)||/^(con|prn|aux|nul|com[1-9]|lpt[1-9])(\.|$)/i.test(part)))throw Error('Ruta insegura en el paquete.');
 const target=path.resolve(root,name);if(!target.startsWith(path.resolve(root)+path.sep))throw Error('Ruta fuera de la instancia.');return target;
}
async function extract(zipPath,destination){
 const zip=await new Promise((resolve,reject)=>yauzl.open(zipPath,{lazyEntries:true,strictFileNames:true,validateEntrySizes:true},(e,z)=>e?reject(e):resolve(z)));
 return new Promise((resolve,reject)=>{
  let total=0,count=0,failed=false;const seen=new Set();
  function fail(error){if(failed)return;failed=true;zip.close();reject(error)}
  zip.on('error',fail);zip.on('end',resolve);
  zip.on('entry',async entry=>{
   try{
    if(failed)return;
    const target=safeTarget(destination,entry.fileName);const key=target.toLowerCase();
    if(seen.has(key))throw Error('Archivo duplicado en el paquete.');seen.add(key);
    const type=(entry.externalFileAttributes>>>16)&0xf000;
    if(type===0xa000||(entry.generalPurposeBitFlag&1))throw Error('El paquete contiene enlaces o archivos cifrados.');
    total+=entry.uncompressedSize;count++;
    if(total>8*1024**3||count>100000)throw Error('El paquete supera los límites de extracción.');
    if(entry.fileName.endsWith('/'))await fs.mkdir(target,{recursive:true});
    else{
     await fs.mkdir(path.dirname(target),{recursive:true});
     const stream=await new Promise((res,rej)=>zip.openReadStream(entry,(e,s)=>e?rej(e):res(s)));
     await pipeline(stream,fssync.createWriteStream(target,{flags:'wx'}));
    }
    if(!failed)zip.readEntry();
   }catch(error){fail(error)}
  });zip.readEntry();
 });
}
async function installPackage({url,sha256,root,validate,progress}){
 if(!/^https:\/\//.test(url)||!/^[a-f0-9]{64}$/i.test(sha256||''))throw Error('Paquete no válido.');
 await fs.mkdir(path.dirname(root),{recursive:true});
 const staging=await fs.mkdtemp(path.join(path.dirname(root),'.package-'));
 const zipPath=path.join(staging,'download.zip');const destination=path.join(staging,'client');await fs.mkdir(destination);
 try{
  progress.state='Descargando paquete';const response=await fetch(url,{signal:AbortSignal.timeout(600000)});
  if(!response.ok||!response.body)throw Error('No se pudo descargar el paquete.');
  const hash=crypto.createHash('sha256');let length=0;
  const checker=new Transform({transform(chunk,_encoding,callback){length+=chunk.length;if(length>2*1024**3)return callback(Error('El paquete supera 2 GB.'));hash.update(chunk);callback(null,chunk)}});
  await pipeline(Readable.fromWeb(response.body),checker,fssync.createWriteStream(zipPath,{flags:'wx'}));
  if(hash.digest('hex')!==sha256.toLowerCase())throw Error('El SHA-256 del paquete no coincide.');
  progress.state='Extrayendo paquete';await extract(zipPath,destination);
  const manifest=JSON.parse(await fs.readFile(path.join(destination,'launcher.json'),'utf8'));validate(manifest);
  for(const item of manifest.launch.classpath||[])await fs.access(safeTarget(destination,item));
  await fs.writeFile(path.join(destination,'installed-manifest.json'),JSON.stringify(manifest));
  await fs.writeFile(path.join(destination,'.installed-package.sha256'),sha256.toLowerCase());
  const backup=root+'.previous-'+Date.now();let moved=false;
  try{await fs.rename(root,backup);moved=true}catch(error){if(error.code!=='ENOENT')throw error}
  try{await fs.rename(destination,root)}catch(error){if(moved)await fs.rename(backup,root);throw error}
  return manifest;
 }finally{await fs.rm(staging,{recursive:true,force:true})}
}
module.exports={installPackage,extract,safeTarget};
