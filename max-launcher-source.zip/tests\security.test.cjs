const {test}=require('node:test');const assert=require('node:assert/strict');
const path=require('path');const {pathToFileURL}=require('url');
const {blockedShortcut,trustedSender,externalUrl,windowPreferences,secureWindow}=require('../src/main/security.cjs');
test('inspection and reload shortcuts blocked, normal form shortcuts work',()=>{
 for(const input of [{key:'F12'},{key:'I',control:true,shift:true},{key:'c',control:true,shift:true},{key:'U',control:true},{key:'R',control:true},{key:'F5'}])assert.equal(blockedShortcut(input),true);
 for(const input of [{key:'c',control:true},{key:'v',control:true},{key:'a',control:true},{key:'Enter'},{key:'Tab'}])assert.equal(blockedShortcut(input),false);
});
test('only the top-level local UI may send IPC',()=>{
 const file=path.resolve('public/index.html');const url=pathToFileURL(file).href;
 assert.equal(trustedSender({senderFrame:{url,parent:null}},file),true);
 assert.equal(trustedSender({senderFrame:{url,parent:{}}},file),false);
 assert.equal(trustedSender({senderFrame:{url:'https://attacker.example',parent:null}},file),false);
});
test('external URLs cannot launch programs or file handlers',()=>{
 for(const url of ['file:///C:/Windows/cmd.exe','javascript:alert(1)','cmd://test','http://example.com','https://name:pass@example.com'])assert.throws(()=>externalUrl(url));
 assert.equal(externalUrl('https://tortieza.com'),'https://tortieza.com/');
});
test('window protections deny popups, navigation, permissions and inspection',()=>{
 const listeners={};let removed=false,visible=true,open,check,permission;
 const win={removeMenu:()=>removed=true,setMenuBarVisibility:v=>visible=v,webContents:{on:(event,fn)=>listeners[event]=fn,setWindowOpenHandler:fn=>open=fn,closeDevTools:()=>{},session:{setPermissionRequestHandler:fn=>permission=fn,setPermissionCheckHandler:fn=>check=fn}}};
 secureWindow(win,path.resolve('public/index.html'));assert.equal(removed,true);assert.equal(visible,false);assert.equal(open().action,'deny');assert.equal(check(),false);
 permission(null,'camera',value=>assert.equal(value,false));let prevented=false;listeners['will-navigate']({preventDefault:()=>prevented=true},'https://attacker.example');assert.equal(prevented,true);
 assert.equal(windowPreferences('preload').devTools,false);assert.equal(windowPreferences('preload').sandbox,true);
});
