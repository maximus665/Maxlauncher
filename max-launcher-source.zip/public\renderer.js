'use strict';

const $ = id => document.getElementById(id);
const api = window.launcher;
const adminUpdatesTab=document.createElement('button');adminUpdatesTab.id='admin-updates-tab';adminUpdatesTab.textContent='Actualizaciones';
$('admin-page').querySelector('.tabs').append(adminUpdatesTab);
$('admin-page').append($('admin-updates'));
const state = { account: null, page: 'auth', instances: [], managed: [], selected: null, profileId: null, editing: null, deleting: null, playing: false, syncing: false, adminTab: 'instances' };
const roles = { player: 'Jugador', moderator: 'Moderador', admin: 'Administrador', owner: 'Dueño' };
let noticeTimer;
let countdownTimer;
let searchVersion = 0;
const saveLocks = new Map();
function beginSave(form) {
  const lock = saveLocks.get(form.id);
  if (lock?.busy || (lock?.until || 0) > Date.now()) return false;
  saveLocks.set(form.id, {busy: true, until: 0});
  return true;
}
function freezeForm(form) {
  const controls = [...form.elements].map(node => [node, node.disabled]);
  for (const [node] of controls) node.disabled = true;
  return () => { for (const [node, disabled] of controls) node.disabled = disabled; };
}
function finishSave(form, restore) {
  restore();
  const button = form.querySelector('button.primary');
  const original = button.textContent;
  const lock = {busy: false, until: Date.now() + 3000}; saveLocks.set(form.id, lock);
  const tick = () => {
    const seconds = Math.ceil((lock.until - Date.now()) / 1000);
    button.disabled = seconds > 0; button.textContent = seconds > 0 ? 'Espera ' + seconds + ' s' : original;
    if (seconds <= 0) clearInterval(timer);
  };
  const timer = setInterval(tick, 250); tick();
}
const isStaff = () => ['admin', 'owner'].includes(state.account?.profile?.role);
const isOwner = () => state.account?.profile?.role === 'owner';
const canModerate=()=>['moderator','admin','owner'].includes(state.account?.profile?.role);
const rank=role=>({player:1,moderator:2,admin:3,owner:4}[role]||0);
const updateShortcut=$('open-updates');document.querySelector('[data-page="updates"]')?.remove();
const accountDock=el('div','account-dock');$('own-profile').before(accountDock);accountDock.append($('own-profile'),updateShortcut);
updateShortcut.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3v12m-4-4 4 4 4-4M5 17v4h14v-4"/></svg><span>0.3.3</span>';
updateShortcut.className='version-shortcut';updateShortcut.setAttribute('aria-label','Versión 0.3.3 · Actualizaciones');
$('signin-form').before($('banned-access'));

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text != null) node.textContent = String(text);
  return node;
}
function notice(message) {
  $('notice').textContent = message;
  $('notice').classList.add('visible');
  clearTimeout(noticeTimer);
  noticeTimer = setTimeout(() => $('notice').classList.remove('visible'), 5000);
}
function imageUrl(value) {
  try { const url = new URL(value); return url.protocol === 'https:' ? url.href : ''; } catch { return ''; }
}
function avatar(profile) {
  if(profile?.is_banned)return 'data:image/svg+xml,'+encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="120" height="120"><rect width="120" height="120" fill="#241b23"/><circle cx="60" cy="60" r="31" fill="none" stroke="#e68b94" stroke-width="7"/><path d="m38 38 44 44" stroke="#e68b94" stroke-width="7"/></svg>');
  const url = imageUrl(profile?.avatar_url);
  if (url) return url;
  const letter = String(profile?.username || 'M').replace(/[^a-zA-Z0-9]/g, '').slice(0, 1).toUpperCase() || 'M';
  return 'data:image/svg+xml,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="120" height="120"><rect width="120" height="120" fill="#293746"/><text x="60" y="77" text-anchor="middle" font-family="Arial" font-size="50" fill="#c8ed8b">' + letter + '</text></svg>');
}
function art(node, url) {
  const safe = imageUrl(url);
  node.style.backgroundImage = safe ? 'url("' + safe.replaceAll('"', '%22') + '")' : '';
}
function badgeList(profile) {
  const wrap = el('div', 'badges');
  if(profile?.is_banned){const badge=el('span','banned-symbol','⊘');badge.title='Cuenta baneada';badge.setAttribute('aria-label','Cuenta baneada');wrap.append(badge);return wrap;}
  const kind = { owner: 'owner', admin: 'admin', moderator: 'moderator', player: 'user' }[profile?.role] || 'user';
  wrap.append(roleBadge(kind, profile));
  if (profile?.is_verified) wrap.append(roleBadge('verified', profile));
  return wrap;
}
function roleBadge(kind, profile) {
  const labels = { verified: 'Verificado', owner: 'Dueño', user: 'Usuario', admin: 'Administrador', moderator: 'Moderador' };
  // Vector insignias created in the Lovable design; no user-provided markup.
  const graphics = {
    verified: '<path fill="currentColor" d="m11 1.6 2.16 1.64 2.7-.15.7 2.62 2.27 1.48-.98 2.52.98 2.52-2.27 1.48-.7 2.62-2.7-.15L11 17.82l-2.16-1.64-2.7.15-.7-2.62-2.27-1.48.98-2.52-.98-2.52 2.27-1.48.7-2.62 2.7.15L11 1.6Z"/><path d="m7.3 10.8 2.35 2.2 5.05-5.1" stroke="#0b0d12" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>',
    owner: '<path fill="currentColor" d="m3.1 6.2 4.25 3.25L11 4.1l3.65 5.35L18.9 6.2l-1.45 10.1H4.55L3.1 6.2Z"/><path d="M5 18h12" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>',
    user: '<path d="M11 2.5 18 5v5.25c0 4.15-2.75 7.35-7 9.25-4.25-1.9-7-5.1-7-9.25V5l7-2.5Z" fill="currentColor"/><circle cx="11" cy="8.5" r="2.2" fill="#0b0d12"/><path d="M7.7 14.75c.45-1.65 1.55-2.55 3.3-2.55s2.85.9 3.3 2.55" stroke="#0b0d12" stroke-width="1.5" stroke-linecap="round"/>',
    admin: '<path d="M11 2.2 18.2 5v5.2c0 4.35-2.85 7.5-7.2 9.6-4.35-2.1-7.2-5.25-7.2-9.6V5L11 2.2Z" fill="currentColor"/><path d="M11 6v8M7 10h8" stroke="#0b0d12" stroke-width="1.7" stroke-linecap="round"/>',
    moderator: '<path d="M11 2.4 18 5.1v5.15c0 4.15-2.7 7.25-7 9.35-4.3-2.1-7-5.2-7-9.35V5.1L11 2.4Z" fill="currentColor"/><path d="M7.4 11h7.2M11 7.4v7.2" stroke="#0b0d12" stroke-width="1.45" stroke-linecap="round"/><circle cx="11" cy="11" r="4.55" stroke="#0b0d12" stroke-width="1.15"/>'
  };
  const badge = el('span', 'role-icon role-icon-' + kind);
  badge.title = labels[kind]; badge.setAttribute('role', 'button'); badge.setAttribute('aria-label', labels[kind]); badge.tabIndex = 0;
  badge.setAttribute('aria-haspopup', 'dialog');
  badge.onclick = event => { event.stopPropagation(); openBadgeInfo(kind, profile); };
  badge.onkeydown = event => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); event.stopPropagation(); openBadgeInfo(kind, profile); } };
  badge.innerHTML = '<svg viewBox="0 0 22 22" width="22" height="22" fill="none" aria-hidden="true">' + graphics[kind] + '</svg>';
  return badge;
}
async function openBadgeInfo(kind, profile) {
  if (!state.account || !profile?.id) return;
  try {
    const current = (await api.userDetail(profile.id)).profile;
    if (!state.account) return;
    if (!current || (kind === 'verified' ? !current.is_verified : ({owner:'owner',admin:'admin',moderator:'moderator',user:'player'}[kind] !== current.role))) { notice('Esta insignia ya no está activa'); return; }
    const labels = {verified:'Cuenta verificada',owner:'Dueño',admin:'Administrador',moderator:'Moderador',user:'Usuario'};
    const descriptions = {verified:'Esta cuenta ha recibido la insignia de verificación de MaxMaxstudios.',owner:'Esta cuenta pertenece al dueño de MaxMaxstudios y puede gestionar los permisos y las instancias.',admin:'Esta cuenta tiene permisos para gestionar las instancias de MaxMaxstudios.',moderator:'Esta cuenta tiene el rol de moderador de MaxMaxstudios.',user:'Esta cuenta está registrada en MaxMaxstudios.'};
    const icon = roleBadge(kind, current); icon.removeAttribute('tabindex'); icon.setAttribute('role','img'); icon.onclick = null; icon.onkeydown = null;
    $('badge-info-icon').replaceChildren(icon);
    $('badge-info-title').textContent = labels[kind];
    $('badge-info-user').textContent = current.username;
    $('badge-info-description').textContent = descriptions[kind];
    const since = kind === 'verified' ? current.verified_at : kind === 'user' ? current.created_at : current.role_since;
    $('badge-info-date').textContent = since ? (kind === 'verified' ? 'Verificada desde el ' : 'Desde el ') + new Date(since).toLocaleDateString('es-MX',{dateStyle:'long',timeZone:'America/Mexico_City'}) : 'Fecha no registrada';
    $('badge-info').showModal();
  } catch(error) { notice(error.message); }
}
function empty(target, message) { target.replaceChildren(el('div', 'empty', message)); }
function date(value) { return value ? new Date(value).toLocaleString('es-MX', { dateStyle: 'medium', timeStyle: 'short' }) : 'Sin límite'; }
function status(row) {
  if (!row.is_published) return 'Borrador';
  if (row.availability_end && Date.parse(row.availability_end) <= Date.now()) return 'Finalizada';
  if (row.availability_start && Date.parse(row.availability_start) > Date.now()) return 'Programada';
  if (row.status === 'online' && !row.package_url && !row.manifest_url) return 'Próximamente';
  return { online: 'Disponible', maintenance: 'Mantenimiento', archived: 'Archivada' }[row.status] || 'Disponible';
}
function canPlay(row) {
  const rank = { player: 1, moderator: 2, admin: 3, owner: 4 };
  return Boolean((row?.package_url || row?.manifest_url) && row.is_published && row.status === 'online' && (rank[state.account?.profile?.role] || 0) >= (rank[row.min_role] || 1) && (!row.availability_start || Date.parse(row.availability_start) <= Date.now()) && (!row.availability_end || Date.parse(row.availability_end) > Date.now()));
}
function localDate(value) {
  if (!value) return '';
  const d = new Date(value);
  return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
}

async function navigate(page) {
  if (!state.account && !['auth','updates'].includes(page)) page = 'auth';
  if (page === 'admin' && !isStaff()) page = 'instances';
  if(page==='moderation' && !canModerate())page='instances';
  state.page = page;
  api.instancePresence?.(page === 'detail' ? state.selected?.id : null).catch(() => {});
  document.querySelectorAll('.page').forEach(node => { node.hidden = node.id !== page + '-page'; });
  document.querySelectorAll('[data-page]').forEach(node => node.classList.toggle('active', node.dataset.page === page));
  $('page-title').textContent = { auth: 'Acceso', home:'Inicio', moderation:'Moderación', instances: 'Instancias', users: 'Usuarios', profile: 'Perfil', detail: 'Detalle de instancia', admin: 'Administración', updates:'Actualizaciones' }[page];
  if (page !== 'detail') clearInterval(countdownTimer);
  try {
    if (page === 'instances') await loadInstances();
    if (page === 'users') await loadUsers();
    if (page === 'admin') await loadAdmin();
    if(page==='moderation')await loadModeration();
    if(page==='home')await loadHome();
  } catch (error) { notice(error.message); }
}
function updateAccountUi() {
  const profile = state.account?.profile;
  $('admin-nav').hidden = !isStaff();
  $('moderation-nav').hidden=!canModerate();
  $('signout').hidden = !state.account;
  document.querySelectorAll('[data-page]').forEach(button => { button.disabled = !state.account && button.dataset.page !== 'updates'; });
  $('rail-name').textContent = profile?.username || 'Cuenta';
  $('rail-badges').replaceChildren(...(profile ? badgeList(profile).children : []));
  $('rail-avatar').src = avatar(profile);
  $('admin-permissions-tab').hidden = !isOwner();
  if (!isOwner() && state.adminTab === 'permissions') setAdminTab('instances');
}
async function initialize() {
  try { const account = await api.me(); state.account = account.user && account.profile ? account : null; } catch(error) { state.account = null;showBanNotice(error); }
  updateAccountUi();
  if(state.account)$('banned-access').hidden=true;
  await navigate(state.account ? 'home' : 'auth');
}
function showBanNotice(error){
  const index=String(error.message||'').indexOf('BAN_INFO:');if(index<0)return false;
  try{const data=JSON.parse(error.message.slice(index+9));$('banned-access').hidden=false;$('banned-access-reason').textContent=data.reason;$('banned-access-until').textContent=data.expiresAt?'Hasta '+date(data.expiresAt):'Baneo permanente';return true;}catch{return false;}
}
async function loadHome(){
  const rows=await api.instances();if(state.page!=='home')return;
  const featured=rows.find(r=>r.status==='online')||rows[0];
  $('home-name').textContent=featured?.name||'MAX LAUNCHER';$('home-description').textContent=featured?.description||'Experiencias y eventos de nuestra comunidad.';
  $('home-count').textContent=rows.length+' instancias';$('home-user').textContent=state.account.profile.username;
  art($('home-hero'),featured?.banner_url||featured?.image_url);
  $('home-explore').textContent=featured?'Ver instancia':'Ver instancias';$('home-explore').onclick=()=>featured?openInstance(featured):navigate('instances');
}
function makeInstanceCard(row) {
  const card = el('article', 'instance-card');
  const open = el('button', 'card-open');
  open.type = 'button'; open.setAttribute('aria-label', 'Ver ' + row.name);
  const banner = el('div', 'card-art');
  art(banner, row.image_url || row.banner_url);
  banner.append(el('span', 'badge', status(row)), el('span', 'card-initials', String(row.name).slice(0, 2).toUpperCase()));
  const content = el('div', 'card-content');
  content.append(el('h2', '', row.name), el('p', 'card-description', row.description || 'Sin descripción'));
  open.append(banner, content);
  open.onclick = () => openInstance(row);
  const footer = el('div', 'card-footer');
  footer.append(el('span', 'card-author', row.creator?.username || 'MaxMaxstudios'), el('span', 'muted', row.minecraft_version || ''));
  card.append(open, footer);
  return card;
}
async function loadInstances() {
  const rows = await api.instances();
  state.instances = rows;
  $('instance-count').textContent = rows.length + (rows.length === 1 ? ' instancia' : ' instancias');
  $('catalog').replaceChildren(...rows.map(makeInstanceCard));
  if (!rows.length) empty($('catalog'), 'Sin instancias disponibles');
}
async function openInstance(row) {
  state.selected = row;
  art($('event-banner'), row.banner_url || row.image_url);
  $('event-name').textContent = row.name;
  $('event-state').textContent = status(row);
  $('event-description').textContent = row.description || 'Sin descripción';
  $('event-tags').replaceChildren(...[row.minecraft_version && 'Minecraft ' + row.minecraft_version, row.loader, row.instance_version && 'v' + row.instance_version].filter(Boolean).map(value => el('span', 'event-tag', value)));
  renderPublisher(row.creator, row.created_by);
  $('event-author').onclick = $('event-author-profile').onclick = () => row.created_by && openUser(row.created_by);
  const metadata = { Minecraft: row.minecraft_version || '—', Loader: row.loader || '—', Versión: row.instance_version || '—', Inicio: date(row.availability_start), Finalización: date(row.availability_end), Acceso: roles[row.min_role] || 'Jugador' };
  $('event-metadata').replaceChildren();
  for (const [key, value] of Object.entries(metadata)) {
    const item = el('div', 'specification'); item.append(el('dt', '', key), el('dd', '', value)); $('event-metadata').append(item);
  }
  $('event-play').disabled = !canPlay(row) || state.playing;
  $('event-play').textContent = canPlay(row) ? 'Jugar' : status(row);
  $('event-play').onclick = () => play(row);
  await navigate('detail');
  updateCountdown();
  clearInterval(countdownTimer);
  countdownTimer = setInterval(updateCountdown, 1000);
  if (row.created_by) {
    try {
      const result = await api.userDetail(row.created_by);
      if (state.account && state.page === 'detail' && state.selected === row && result.profile) renderPublisher(result.profile, row.created_by);
    } catch { /* The embedded public author remains available if the request fails. */ }
  }
}
function renderPublisher(profile, id) {
  const publisher = {...profile, id};
  $('event-author-name').textContent = publisher.username || 'MaxMaxstudios';
  $('event-author-avatar').src = avatar(publisher);
  $('event-author-avatar').onerror = () => { $('event-author-avatar').onerror = null; $('event-author-avatar').src = avatar({...publisher, avatar_url: null}); };
  $('event-author-badges').replaceChildren(...(profile ? badgeList(publisher).children : []));
  $('event-author-bio').textContent = publisher.bio || '';
  $('event-author-bio').hidden = !publisher.bio;
  $('event-author').disabled = $('event-author-profile').disabled = !id;
  art(document.querySelector('.publisher-cover'), publisher.banner_url);
}
function updateCountdown() {
  const row = state.selected;
  if (!row || state.page !== 'detail') return;
  const untilStart = row.availability_start && Date.parse(row.availability_start) > Date.now();
  const end = untilStart ? row.availability_start : row.availability_end;
  const diff = end ? Math.max(0, Date.parse(end) - Date.now()) : 0;
  const secs = Math.floor(diff / 1000);
  $('event-countdown').textContent = end ? (untilStart ? 'Inicio en ' : 'Tiempo restante: ') + Math.floor(secs / 86400) + 'd ' + String(Math.floor(secs / 3600) % 24).padStart(2, '0') + ':' + String(Math.floor(secs / 60) % 60).padStart(2, '0') + ':' + String(secs % 60).padStart(2, '0') : '';
  if (!state.playing) { $('event-play').disabled = !canPlay(row); $('event-play').textContent = canPlay(row) ? 'Jugar' : status(row); }
}
async function play(row) {
  if (state.playing || !canPlay(row)) return;
  state.playing = true;
  $('event-play').disabled = true;
  $('event-play').textContent = 'Preparando…';
  try { await api.sync(row.id); await api.launch(); notice('Instancia iniciada'); } catch (error) { notice(error.message); }
  finally { state.playing = false; updateCountdown(); }
}
async function loadUsers() {
  const version = ++searchVersion;
  const rows = await api.users($('user-query').value);
  if (version !== searchVersion) return;
  $('user-count').textContent = rows.length + ' resultados';
  $('user-list').replaceChildren(...rows.map(profile => {
    const card = el('button', 'user-card'); card.type = 'button';
    const img = el('img'); img.src = avatar(profile); img.alt = '';
    const content = el('div', 'user-identity'); content.append(el('h2', '', profile.username), badgeList(profile));
    card.append(img, content); card.onclick = () => openUser(profile.id); return card;
  }));
  if (!rows.length) empty($('user-list'), 'Sin resultados');
}
async function openUser(id) {
  try {
    const result = await api.userDetail(id);
    if (!result.profile) throw new Error('Usuario no encontrado');
    state.profileId = id;
    const p = result.profile;
    $('profile-avatar').src = avatar(p);
    art($('profile-banner'), p.is_banned?null:p.banner_url);
    $('profile-page').classList.toggle('banned-profile',!!p.is_banned);
    $('profile-name').textContent = p.username;
    $('profile-badges').replaceChildren(badgeList(p));
    $('profile-description').textContent = p.is_banned?'Esta cuenta fue baneada por incumplimiento de las normas de la comunidad. Motivo: '+p.ban_public_reason+(p.ban_expires_at?' · Hasta '+date(p.ban_expires_at):' · Baneo permanente'):p.bio || 'Sin descripción';
    $('profile-date').textContent = p.created_at ? new Date(p.created_at).toLocaleDateString('es-MX', { dateStyle: 'long' }) : '—';
    $('edit-profile').hidden = id !== state.account.user.id;
    $('profile-instances').replaceChildren(...(p.is_banned?[]:result.instances).map(makeInstanceCard));
    if (!result.instances.length) empty($('profile-instances'), 'Sin instancias');
    await navigate('profile');
  } catch (error) { notice(error.message); }
}

function setAdminTab(tab) {
  if (tab === 'permissions' && !isOwner()) return;
  state.adminTab = tab;
  $('admin-instances').hidden = tab !== 'instances';
  $('admin-permissions').hidden = tab !== 'permissions';
  $('admin-updates').hidden = tab !== 'updates';
  $('admin-updates-tab').classList.toggle('selected', tab === 'updates');
  if(tab === 'updates')loadAdminUpdates().catch(error=>notice(error.message));
  $('admin-instances-tab').classList.toggle('selected', tab === 'instances');
  $('admin-permissions-tab').classList.toggle('selected', tab === 'permissions');
  if (tab === 'permissions') loadPermissions().catch(error => notice(error.message));
}
async function loadAdmin() {
  if (!isStaff()) return;
  const rows = await api.managedInstances();
  state.managed = rows;
  $('stat-total').textContent = rows.length;
  $('stat-live').textContent = rows.filter(r => r.is_published).length;
  $('stat-scheduled').textContent = rows.filter(r => status(r) === 'Programada').length;
  $('managed-list').replaceChildren(...rows.map(row => {
    const tr = el('tr');
    const nameCell = el('td');
    const name = el('div', 'table-name');
    const thumbnail = el('div', 'table-thumbnail'); art(thumbnail, row.image_url || row.banner_url);
    const caption = el('div'); caption.append(el('strong', '', row.name), el('small', '', row.minecraft_version || row.slug));
    name.append(thumbnail, caption); nameCell.append(name);
    const statusCell = el('td'); statusCell.append(el('span', 'badge ' + (!row.is_published ? 'neutral' : ''), status(row)));
    const scheduleCell = el('td'); scheduleCell.append(el('div', '', row.availability_start ? date(row.availability_start) : 'Permanente'));
    if (row.availability_end) scheduleCell.append(el('small', 'muted', 'Hasta ' + date(row.availability_end)));
    const actions = el('td'); const buttons = el('div', 'row-actions');
    const view = el('button', 'secondary', 'Ver'); view.onclick = () => openInstance(row);
    const edit = el('button', 'secondary', 'Editar'); edit.onclick = () => openEditor(row);
    const publish = el('button', 'secondary', row.is_published ? 'Ocultar' : 'Publicar');
    publish.onclick = async () => { publish.disabled = true; try { await api.updateInstance(row.id, { ...row, is_published: !row.is_published }); await loadAdmin(); notice('Publicación actualizada'); } catch (error) { notice(error.message); publish.disabled = false; } };
    const remove = el('button', 'danger', 'Eliminar'); remove.onclick = () => requestDelete(row);
    buttons.append(view, edit, publish, remove); actions.append(buttons);
    tr.append(nameCell, statusCell, scheduleCell, el('td', '', row.creator?.username || 'MaxMaxstudios'), actions);
    return tr;
  }));
  if (!rows.length) { const tr = el('tr'); const td = el('td', 'empty', 'Sin instancias'); td.colSpan = 5; tr.append(td); $('managed-list').append(tr); }
}
function openEditor(row = null) {
  if (!isStaff()) return;
  state.editing = row ? { ...row } : null;
  const form = $('instance-form'); form.reset();
  $('editor-title').textContent = row ? 'Editar instancia' : 'Nueva instancia';
  $('editor-error').textContent = '';
  for (const name of ['name', 'slug', 'description', 'package_url', 'package_sha256', 'minecraft_version', 'loader', 'instance_version', 'status', 'min_role']) {
    form.elements[name].value = row?.[name] ?? ({ status: 'online', min_role: 'player' }[name] || '');
  }
  form.elements.availability_start.value = localDate(row?.availability_start);
  form.elements.availability_end.value = localDate(row?.availability_end);
  form.elements.is_published.checked = row?.is_published ?? true;
  art($('editor-banner-preview'), row?.banner_url);
  art($('editor-cover-preview'), row?.image_url);
  $('instance-editor').showModal();
}
async function dataUrl(file) {
  if (!['image/png', 'image/jpeg', 'image/webp'].includes(file.type) || file.size > 5 * 1024 * 1024) throw new Error('Imagen no válida. Límite: 5 MB.');
  return new Promise((resolve, reject) => { const reader = new FileReader(); reader.onload = () => resolve(reader.result); reader.onerror = () => reject(new Error('No se pudo leer la imagen')); reader.readAsDataURL(file); });
}
function preview(fileInput, target) {
  fileInput.onchange = async () => {
    if (!fileInput.files[0]) return;
    try { const url = await dataUrl(fileInput.files[0]); target.style.backgroundImage = 'url("' + url + '")'; } catch (error) { $('editor-error').textContent = error.message; fileInput.value = ''; }
  };
}
async function saveInstance(event) {
  event.preventDefault();
  const form = event.currentTarget;
  if (!beginSave(form)) return;
  const values = Object.fromEntries(new FormData(form));
  values.is_published = form.elements.is_published.checked;
  const files = [['editor-banner-file', 'banner_url'], ['editor-cover-file', 'image_url']].map(([input, key]) => [$(input).files[0], key]);
  const restore = freezeForm(form);
  const uploaded = [];
  $('editor-error').textContent = '';
  try {
    values.manifest_url = state.editing?.manifest_url || null;
    values.image_url = state.editing?.image_url || null;
    values.banner_url = state.editing?.banner_url || null;
    for (const [file, key] of files) {
      if (file) { values[key] = await api.uploadInstanceImage(await dataUrl(file)); uploaded.push(values[key]); }
    }
    if (state.editing) await api.updateInstance(state.editing.id, values);
    else await api.createInstance(values);
    $('instance-editor').close();
    state.editing = null;
    await loadAdmin();
    notice('Instancia guardada');
  } catch (error) {
    $('editor-error').textContent = error.message;
    for (const url of uploaded) await api.removeUnusedImage(url).catch(() => {});
  } finally { finishSave(form, restore); }
}
function requestDelete(row) {
  state.deleting = row;
  $('delete-name').textContent = row.name;
  $('delete-error').textContent = '';
  $('delete-dialog').showModal();
}
async function confirmDelete() {
  const row = state.deleting; if (!row) return;
  $('confirm-delete').disabled = true;
  try {
    const result = await api.deleteInstance(row.id);
    $('delete-dialog').close(); state.deleting = null;
    await loadAdmin();
    notice(result.cleanupPending ? 'Instancia eliminada. Hay imágenes pendientes de limpieza.' : 'Instancia eliminada');
  } catch (error) { $('delete-error').textContent = error.message; }
  finally { $('confirm-delete').disabled = false; }
}
async function loadPermissions() {
  if (!isOwner()) return;
  const rows = await api.users($('permission-query').value);
  $('permissions-list').replaceChildren(...rows.map(profile => {
    const row = el('div', 'permission-row');
    const img = el('img'); img.src = avatar(profile); img.alt = '';
    const select = el('select'); select.setAttribute('aria-label', 'Rol de ' + profile.username);
    for (const [role, label] of Object.entries(roles)) { const option = el('option', '', label); option.value = role; select.append(option); }
    select.value = profile.role;
    select.disabled=profile.role==='owner';
    const label = el('label', 'checkbox');
    const check = el('input'); check.type = 'checkbox'; check.checked = !!profile.is_verified;
    label.append(check, el('span', '', 'Verificado'));
    const button = el('button', 'secondary', 'Guardar');
    button.onclick = async () => {
      button.disabled = true;
      try { await api.managePermissions({ userId: profile.id, role: select.value, verified: check.checked }); notice('Permisos actualizados'); await syncAccount(); }
      catch (error) { notice(error.message); } finally { button.disabled = false; }
    };
    const ban=el('button',profile.is_banned?'secondary':'danger',profile.role==='owner'?'Protegido':profile.is_banned?'Desbanear':'Banear');
    ban.disabled=profile.role==='owner' || profile.id===state.account.user.id;
    ban.onclick=()=>openBanDialog(profile);
    row.append(img, el('strong', '', profile.username+(profile.is_banned?' · Suspendida':'')), select, label, button,ban);
    return row;
  }));
  if (!rows.length) empty($('permissions-list'), 'Sin resultados');
}
function openBanDialog(profile){
 state.banTarget=profile;$('ban-title').textContent=profile.is_banned?'Retirar sanción':'Banear cuenta';$('ban-user').textContent=profile.username;
 $('ban-reason').value='';$('ban-reason-field').hidden=!!profile.is_banned;$('ban-duration-field').hidden=!!profile.is_banned;$('ban-duration').value='permanent';$('ban-error').textContent='';$('ban-confirm').textContent=profile.is_banned?'Desbanear':'Confirmar baneo';$('ban-dialog').showModal();
}
async function loadModeration(){
 if(!canModerate())return;const rows=await api.users($('moderation-query').value);if(state.page!=='moderation')return;
 $('moderation-list').replaceChildren(...rows.map(profile=>{
  const row=el('article','permission-row');const img=el('img');img.src=avatar(profile);
  const identity=el('div','moderation-identity');const name=el('strong','',profile.username);name.append(badgeList(profile));identity.append(name,el('small','muted',profile.is_banned?profile.ban_public_reason||'Cuenta baneada':roles[profile.role]));
  const view=el('button','secondary','Ver perfil');view.onclick=()=>openUser(profile.id);
  const action=el('button',profile.is_banned?'secondary':'danger',profile.is_banned?'Desbanear':'Banear');action.disabled=profile.id===state.account.user.id||rank(profile.role)>=rank(state.account.profile.role);action.onclick=()=>openBanDialog(profile);
  row.append(img,identity,view,action);return row;
 }));if(!rows.length)empty($('moderation-list'),'Sin resultados');
}
async function openProfileEditor() {
  const p = state.account.profile;
  $('profile-form').reset(); $('profile-form').elements.bio.value = p.bio || '';
  $('profile-error').textContent = ''; $('profile-editor').showModal();
}
async function saveProfile(event) {
  event.preventDefault(); const form = event.currentTarget;
  if (!beginSave(form)) return;
  const values = {bio: form.elements.bio.value};
  const files = [['profile-avatar-file', 'avatarUrl'], ['profile-banner-file', 'bannerUrl']].map(([input, key]) => [$(input).files[0], key]);
  const restore = freezeForm(form); const uploaded = [];
  try {
    for (const [file, key] of files) if (file) { values[key] = await api.uploadAvatar(await dataUrl(file)); uploaded.push(values[key]); }
    state.account.profile = await api.updateProfile(values);
    updateAccountUi(); $('profile-editor').close(); await openUser(state.account.user.id); notice('Perfil guardado');
  } catch (error) { $('profile-error').textContent = error.message; for (const url of uploaded) await api.removeUnusedImage(url).catch(() => {}); }
  finally { finishSave(form, restore); }
}
async function logout(message) {
  await api.signOut().catch(() => {});
  state.account = null; state.instances = []; state.managed = []; state.editing = null;
  document.querySelectorAll('dialog[open]').forEach(dialog => dialog.close());
  updateAccountUi(); await navigate('auth');
  $('catalog').replaceChildren(); $('managed-list').replaceChildren(); $('user-list').replaceChildren();
  if (message) notice(message);
}
async function syncAccount() {
  if (!state.account || state.syncing) return;
  state.syncing = true;
  try {
    const account = await api.me();
    if (!account.user || !account.profile) { await logout('Sesión finalizada'); return; }
    const oldRole = state.account.profile?.role;
    state.account = account; updateAccountUi();
    if(state.page==='moderation' && !canModerate()){ $('ban-dialog').close();await navigate('home'); }
    if (oldRole !== account.profile.role && !isStaff()) {
      $('instance-editor').close(); $('delete-dialog').close();
      if (state.page === 'admin') await navigate('instances');
    }
    if (!document.querySelector('dialog[open]') && !state.playing) {
      if(state.page==='profile')await openUser(state.profileId);
      if(state.page==='users')await loadUsers();
      if (state.page === 'instances') {
        const rows = await api.instances();
        if (JSON.stringify(rows) !== JSON.stringify(state.instances)) { state.instances = rows; $('catalog').replaceChildren(...rows.map(makeInstanceCard)); if (!rows.length) empty($('catalog'), 'Sin instancias disponibles'); }
      }
      if (state.page === 'detail') {
        const rows = await api.instances();
        const row = rows.find(item => item.id === state.selected?.id);
        if (!row) await navigate('instances');
        else if (JSON.stringify(row) !== JSON.stringify(state.selected)) await openInstance(row);
      }
    }
    $('connection').textContent = 'Conectado'; $('connection').classList.remove('offline');
  } catch(error) {
    if(error.message?.includes('Cuenta suspendida')) {await logout();showBanNotice(error);return;}
    $('connection').textContent = 'Sin conexión'; $('connection').classList.add('offline');
    await logout('Conexión perdida');
  } finally { state.syncing = false; }
}
document.querySelectorAll('[data-page]').forEach(button => { button.onclick = () => navigate(button.dataset.page); });
document.querySelectorAll('[data-close]').forEach(button => { button.onclick = () => { const dialog = $(button.dataset.close); if (!saveLocks.get(dialog.querySelector('form')?.id)?.busy) dialog.close(); }; });
document.querySelectorAll('dialog').forEach(dialog => dialog.addEventListener('cancel', event => { if (saveLocks.get(dialog.querySelector('form')?.id)?.busy) event.preventDefault(); }));
document.querySelectorAll('[data-auth]').forEach(button => {
  button.onclick = () => { document.querySelectorAll('[data-auth]').forEach(other => other.classList.toggle('selected', other === button)); $('signin-form').hidden = button.dataset.auth !== 'signin'; $('signup-form').hidden = button.dataset.auth !== 'signup'; };
});
for (const id of ['signin', 'signup']) {
  $(id + '-form').onsubmit = async event => {
    event.preventDefault(); const form = event.currentTarget; const button = form.querySelector('button'); button.disabled = true;
    try { const result = await api[id === 'signin' ? 'signIn' : 'signUp'](Object.fromEntries(new FormData(form))); if (result?.needsConfirmation) notice('Cuenta pendiente de confirmación'); await initialize(); }
    catch (error) { if(!showBanNotice(error))notice(error.message); } finally { button.disabled = false; }
  };
}
$('own-profile').onclick = () => state.account ? openUser(state.account.user.id) : navigate('auth');
$('profile-back').onclick = () => navigate('users');
$('detail-back').onclick = () => navigate('instances');
$('signout').onclick = () => logout();
$('create-instance').onclick = () => openEditor();
$('instance-form').onsubmit = saveInstance;
$('confirm-delete').onclick = confirmDelete;
$('admin-instances-tab').onclick = () => setAdminTab('instances');
$('admin-permissions-tab').onclick = () => setAdminTab('permissions');
$('ban-confirm').onclick=async()=>{
  const target=state.banTarget;if(!target || !canModerate())return;
  const button=$('ban-confirm');button.disabled=true;
  try{const duration=$('ban-duration').value;const expiresAt=target.is_banned||duration==='permanent'?null:new Date(Date.now()+Number(duration)*3600000).toISOString();await api.manageBan({userId:target.id,banned:!target.is_banned,reason:$('ban-reason').value,expiresAt});$('ban-dialog').close();state.banTarget=null;if(state.page==='moderation')await loadModeration();else await loadPermissions();notice(target.is_banned?'Cuenta habilitada':'Cuenta suspendida');}
  catch(error){$('ban-error').textContent=error.message;}
  finally{button.disabled=false;}
};
let releaseCandidate=null;
function renderAdminUpdates(result) {
  releaseCandidate=result.candidate;
  $('release-installed').textContent=result.currentVersion;
  $('release-approved').textContent=result.channel?.version || 'Sin publicación';
  $('release-candidate').textContent=result.candidate?.version || 'Sin versión verificada';
  $('release-date').textContent=result.channel?.published_at ? date(result.channel.published_at) : '—';
  $('release-publish').hidden=!isOwner();
  $('release-publish').disabled=!isOwner() || !result.candidate || result.candidate.version===result.channel?.version;
}
async function loadAdminUpdates(){if(api.adminUpdateStatus)renderAdminUpdates(await api.adminUpdateStatus());}
$('admin-updates-tab').onclick=()=>setAdminTab('updates');
$('release-check').onclick=async()=>{
  $('release-check').disabled=true;$('release-result').textContent='Verificando publicación…';
  try {renderAdminUpdates(await api.inspectRelease());$('release-result').textContent=releaseCandidate?'Firma verificada. Publicación lista para distribuir.':'No hay publicaciones disponibles.';}
  catch(error){$('release-result').textContent=error.message;}
  finally{$('release-check').disabled=false;}
};
$('release-publish').onclick=()=>{if(releaseCandidate){$('distribution-version').textContent='Versión '+releaseCandidate.version;$('distribution-dialog').showModal();}};
$('distribution-confirm').onclick=async()=>{
  const button=$('distribution-confirm');button.disabled=true;
  try {renderAdminUpdates(await api.publishUpdate(releaseCandidate.version));$('distribution-dialog').close();$('release-result').textContent='Actualización autorizada. Distribución activa.';}
  catch(error){notice(error.message);}finally{button.disabled=false;}
};
$('user-search-form').onsubmit = event => { event.preventDefault(); loadUsers().catch(error => notice(error.message)); };
$('permission-search-form').onsubmit = event => { event.preventDefault(); loadPermissions().catch(error => notice(error.message)); };
$('edit-profile').onclick = openProfileEditor;
$('profile-form').onsubmit = saveProfile;
preview($('editor-banner-file'), $('editor-banner-preview'));
preview($('editor-cover-file'), $('editor-cover-preview'));
window.addEventListener('offline', () => logout('Conexión perdida'));
window.addEventListener('focus', syncAccount);
setInterval(syncAccount, 8000);
function renderUpdateStatus(update) {
  $('updates-summary-version').textContent=update.version;
  $('updates-summary-status').textContent={idle:'Sin comprobar',checking:'Comprobando',current:'Actualizado',available:'Disponible',downloading:'Descargando · '+(update.progress||0)+'%',waiting:'Esperando conexión',ready:'Lista para instalar',error:'No verificada',disabled:'No disponible'}[update.phase] || '';
  const labels = {idle:'Comprueba si hay una nueva versión.',checking:'Buscando actualizaciones…',current:'Tienes la versión más reciente.',available:'Hay una nueva versión disponible.',downloading:'Descargando actualización verificada…',ready:'La actualización está lista. Cierra Minecraft antes de reiniciar.',disabled:'Actualizaciones no disponibles.',error:update.message || 'No se pudo verificar la actualización.'};
  $('update-version').textContent = 'Max Launcher · ' + update.version;
  $('update-message').textContent = update.phase==='waiting' ? update.message : labels[update.phase] || '';
  $('update-progress').hidden = update.phase !== 'downloading';
  $('update-progress').value = update.progress || 0;
  $('update-download').hidden = !update.canDownload || !update.installed;
  $('update-install').hidden = update.phase !== 'ready' || !update.installed;
  $('update-check').disabled = ['checking','downloading','ready','available'].includes(update.phase);
  if (!update.installed && ['available','ready'].includes(update.phase)) $('update-message').textContent = 'Actualización disponible para la versión instalada de Max Launcher.';
  $('open-updates').classList.toggle('update-pending',['available','ready'].includes(update.phase));$('open-updates').title=['available','ready'].includes(update.phase)?'Nueva versión disponible':'Versión 0.3.3 · Actualizaciones';
}
async function updateAction(action) {
  const buttons = [$('update-check'),$('update-download'),$('update-install')];
  buttons.forEach(button => {button.disabled=true;});
  try { const result = await action(); if(result)renderUpdateStatus(result); }
  catch(error) { $('update-message').textContent=error.message; }
  finally { $('update-download').disabled=false; $('update-install').disabled=false; }
}
$('open-updates').onclick=async()=>{await navigate('updates');if(api.updateStatus)renderUpdateStatus(await api.updateStatus());};
$('manage-update').onclick=async()=>{$('update-dialog').showModal();if(api.updateStatus)renderUpdateStatus(await api.updateStatus());};
$('moderation-search').onsubmit=event=>{event.preventDefault();loadModeration().catch(error=>notice(error.message));};
$('update-check').onclick = () => api.checkUpdates && updateAction(()=>api.checkUpdates());
$('update-download').onclick = () => api.downloadUpdate && updateAction(()=>api.downloadUpdate());
$('update-install').onclick = () => api.installUpdate && updateAction(()=>api.installUpdate());
if(api.updateStatus) setInterval(async()=>{try{renderUpdateStatus(await api.updateStatus());}catch{}},1500);
initialize();
