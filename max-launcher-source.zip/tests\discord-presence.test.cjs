const { test } = require('node:test');
const assert = require('node:assert/strict');
const { EventEmitter } = require('node:events');
const { DiscordPresence, encodeFrame, readDiscordConfig } = require('../src/main/services/discord-presence.cjs');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const ID = '123456789012345678';

function setup(config = { applicationId: ID }) {
  const sockets = [], timers = [];
  let now = 1700000000000;
  const presence = new DiscordPresence(config, {
    platform: 'win32', now: () => now,
    connect: pipe => {
      const socket = new EventEmitter();
      Object.assign(socket, { pipe, destroyed: false, writes: [], write(bytes) { this.writes.push(bytes); }, end(bytes) { this.write(bytes); }, destroy() { this.destroyed = true; this.emit('close'); } });
      sockets.push(socket); return socket;
    },
    delay: (fn, ms) => { const timer = { fn, ms, active: true }; timers.push(timer); return timer; },
    cancel: timer => { if (timer) timer.active = false; }
  });
  const receive = (socket, message) => socket.emit('data', encodeFrame(1, message));
  return { presence, sockets, timers, receive, advance: ms => { now += ms; } };
}
function payload(bytes) { return JSON.parse(bytes.subarray(8).toString('utf8')); }
function ready(context) {
  const socket = context.sockets.at(-1); socket.emit('connect');
  context.receive(socket, { cmd: 'DISPATCH', evt: 'READY' });
  const request = payload(socket.writes.at(-1));
  context.receive(socket, { cmd: 'SET_ACTIVITY', nonce: request.nonce, data: {} });
  return socket;
}

test('invalid or absent application ID disables IPC; numeric IDs must remain strings', () => {
  for (const applicationId of ['', undefined, 'BOT_TOKEN', 123456789012345678]) {
    const context = setup({ applicationId }); context.presence.start();
    assert.equal(context.sockets.length, 0);
    context.presence.stop();
  }
});
test('config handles missing, disabled, malformed and valid public identifiers', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'maxmax-discord-'));
  const file = path.join(dir, 'discord.json');
  try {
    assert.equal(readDiscordConfig(file), null);
    for (const value of ['invalid', JSON.stringify({ enabled: false, applicationId: ID }), JSON.stringify({ applicationId: 'secret' })]) {
      fs.writeFileSync(file, value); assert.equal(readDiscordConfig(file), null);
    }
    fs.writeFileSync(file, JSON.stringify({ applicationId: ID, largeImage: 'maxmax_logo' }));
    assert.deepEqual(readDiscordConfig(file), { applicationId: ID, largeImage: 'maxmax_logo' });
  } finally { fs.rmSync(dir, { recursive: true }); }
});
test('handshake, fragmented frames, activity acknowledgement and PING/PONG', () => {
  const c = setup({ applicationId: ID, largeImage: 'logo' }); c.presence.start(); c.presence.start();
  assert.equal(c.sockets.length, 1);
  const socket = c.sockets[0]; assert.equal(socket.pipe, '\\\\?\\pipe\\discord-ipc-0');
  socket.emit('connect');
  assert.deepEqual(payload(socket.writes[0]), { v: 1, client_id: ID });
  const frame = encodeFrame(1, { cmd: 'DISPATCH', evt: 'READY' });
  socket.emit('data', frame.subarray(0, 5)); assert.equal(socket.writes.length, 1);
  socket.emit('data', frame.subarray(5));
  const command = payload(socket.writes[1]);
  assert.equal(command.cmd, 'SET_ACTIVITY'); assert.equal(command.args.pid, process.pid);
  assert.deepEqual(command.args.activity, { details: 'En Max Launcher', timestamps: { start: 1700000000 }, instance: false, assets: { large_image: 'logo', large_text: 'Max Launcher' } });
  c.receive(socket, { cmd: 'SET_ACTIVITY', nonce: 'wrong' }); assert.equal(c.presence.connected, false);
  c.receive(socket, { cmd: 'SET_ACTIVITY', nonce: command.nonce }); assert.equal(c.presence.connected, true);
  socket.emit('data', encodeFrame(3, Buffer.from('ping')));
  assert.equal(socket.writes.at(-1).readUInt32LE(0), 4);
  assert.equal(socket.writes.at(-1).subarray(8).toString(), 'ping');
  c.presence.stop();
  assert.equal(payload(socket.writes.at(-1)).args.activity, null);
  assert.equal(c.presence.connected, false);
  socket.emit('close'); assert.equal(c.sockets.length, 1);
});
test('finds alternate Discord pipes and backs off when Discord is closed', () => {
  const c = setup(); c.presence.start();
  for (let index = 0; index < 10; index++) c.sockets[index].emit('error', Error('ENOENT'));
  assert.equal(c.sockets.length, 10);
  const retry = c.timers.find(timer => timer.active); assert.equal(retry.ms, 5000);
  retry.fn(); assert.equal(c.sockets.length, 11);
  ready(c); assert.equal(c.presence.connected, true);
  c.sockets.at(-1).emit('error', Error('Disconnect'));
  assert.equal(c.presence.connected, false);
  assert.equal(c.presence.retryTimer.ms, 5000);
  c.presence.stop(); assert.equal(c.presence.retryTimer, null);
});
test('handshake or activity timeout never blocks launcher and retries', () => {
  const c = setup(); c.presence.start();
  c.timers[0].fn(); assert.equal(c.sockets.length, 2);
  c.sockets[1].emit('connect'); c.receive(c.sockets[1], { cmd: 'DISPATCH', evt: 'READY' });
  c.presence.attemptTimer.fn(); assert.equal(c.presence.retryTimer.ms, 5000);
  c.presence.stop();
});

test('instance image and name are queued, latest selection wins and general state resets', () => {
  const c = setup(); c.presence.start(); const socket = ready(c);
  c.presence.setInstance({ name: 'Primera', image_url: 'https://images.example/first.png' });
  c.presence.setInstance({ name: 'Horizonte', image_url: 'https://images.example/horizonte.webp' });
  assert.equal(socket.writes.length, 2);
  c.advance(15000); c.presence.updateTimer.fn();
  let request = payload(socket.writes.at(-1));
  assert.equal(request.args.activity.state, 'Viendo Horizonte');
  assert.equal(request.args.activity.assets.large_image, 'https://images.example/horizonte.webp');
  assert.equal(request.args.activity.timestamps.start, 1700000000);
  c.receive(socket, { cmd: 'SET_ACTIVITY', nonce: request.nonce });
  c.presence.setInstance(null); c.advance(15000); c.presence.updateTimer.fn();
  request = payload(socket.writes.at(-1));
  assert.equal(request.args.activity.state, undefined); assert.equal(request.args.activity.assets, undefined);
  c.presence.stop();
});

test('reconnection preserves selected instance, fallback banner and safe image URLs', () => {
  const c = setup();
  c.presence.setInstance({ name: 'Aventura', image_url: 'file:///private.png', banner_url: 'https://images.example/banner.png' });
  c.presence.start(); let socket = ready(c);
  assert.equal(payload(socket.writes[1]).args.activity.assets.large_image, 'https://images.example/banner.png');
  socket.emit('close'); c.presence.retryTimer.fn(); socket = ready(c);
  assert.equal(payload(socket.writes[1]).args.activity.state, 'Viendo Aventura');
  for (const image_url of ['javascript:alert(1)', 'https://user:secret@example.com/image.png', 'https://example.com/image.png?token=secret', 'http://example.com/image.png']) {
    c.presence.setInstance({ name: 'Segura', image_url }); assert.equal(c.presence.activity().assets, undefined);
  }
  c.presence.stop();
});
test('malformed, oversized and rejected RPC frames disconnect safely', () => {
  for (const frame of [encodeFrame(1, Buffer.from('{bad json')), encodeFrame(1, null), encodeFrame(1, { evt: 'ERROR', data: { code: 4000 } }), (() => { const header = Buffer.alloc(8); header.writeUInt32LE(1048577, 4); return header; })()]) {
    const c = setup(); c.presence.start(); const socket = c.sockets[0];
    socket.emit('data', frame); assert.equal(socket.destroyed, true);
    assert.equal(c.presence.connected, false); c.presence.stop();
  }
});

test('playing uses actual game start time and persists across navigation and reconnection', () => {
  const c = setup({applicationId: ID, largeImage: 'max_launcher'}); c.presence.start(); ready(c);
  c.advance(60000);
  c.presence.gameStarted({name:'Horizonte', image_url:'https://example.com/instance.png'});
  let activity = c.presence.activity();
  assert.equal(activity.details, 'Jugando Minecraft');
  assert.equal(activity.state, 'Jugando en Horizonte');
  assert.equal(activity.timestamps.start, 1700000060);
  c.advance(120000); c.presence.setInstance({name:'Otra instancia'});
  assert.equal(c.presence.activity().timestamps.start, 1700000060);
  assert.equal(c.presence.activity().state, 'Jugando en Horizonte');
  c.presence.gameStarted({name:'No debe reiniciar'});
  assert.equal(c.presence.activity().timestamps.start, 1700000060);
  c.sockets.at(-1).emit('close'); c.presence.retryTimer.fn(); const socket = ready(c);
  assert.equal(payload(socket.writes[1]).args.activity.timestamps.start, 1700000060);
  c.presence.gameEnded(); activity=c.presence.activity();
  assert.equal(activity.details,'En Max Launcher'); assert.equal(activity.state,'Viendo Otra instancia');
  c.presence.setInstance(null); assert.equal(c.presence.activity().assets.large_image,'max_launcher');
  c.presence.stop();
});
