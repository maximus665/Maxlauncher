const {test}=require('node:test');const assert=require('node:assert/strict');const crypto=require('node:crypto');const fs=require('node:fs/promises');const path=require('node:path');const os=require('node:os');const {EventEmitter}=require('node:events');
const {verifyManifest,artifactName,manifestName,releaseUrl,APP_ID}=require('../src/main/services/update-policy.cjs');const {LauncherUpdates}=require('../src/main/services/launcher-updates.cjs');const {installAppImage}=require('../src/main/services/linux-update.cjs');
test('Linux signature is platform-specific; updater fetches Linux metadata and downloads AppImage',async()=>{
 const dir=await fs.mkdtemp(path.join(os.tmpdir(),'max-linux-')),keys=crypto.generateKeyPairSync('ed25519'),payload=Buffer.from('TEST APPIMAGE');
 const m={schemaVersion:1,appId:APP_ID,platform:'linux-x64',repository:'maximus665/Maxlauncher',version:'0.3.4',size:payload.length,sha512:crypto.createHash('sha512').update(payload).digest('hex'),issuedAt:new Date().toISOString(),expiresAt:new Date(Date.now()+86400000).toISOString(),url:releaseUrl('maximus665/Maxlauncher','0.3.4',artifactName('0.3.4','linux-x64'))};
 const bytes=Buffer.from(JSON.stringify(m)),signature=crypto.sign(null,bytes,keys.privateKey).toString('base64'),pem=keys.publicKey.export({type:'spki',format:'pem'});let runs=0;
 const options={repository:m.repository,currentVersion:'0.3.3',platform:'linux-x64'};
 assert.throws(()=>verifyManifest(bytes,signature,pem,{...options,platform:'win32-x64'}));assert.equal(verifyManifest(bytes,signature,pem,options).platform,'linux-x64');
 const updater=new LauncherUpdates({...options,publicKey:pem,userData:()=>dir,installed:true,runInstaller:async()=>runs++,fetcher:async url=>{
  if(url.includes('api.github.com'))return Response.json({tag_name:'v0.3.4'});
  if(url.endsWith(manifestName('linux-x64')))return new Response(bytes);
  if(url.endsWith(manifestName('linux-x64',true)))return new Response(signature);
  assert.equal(url,m.url);return new Response(payload);
 }});
 try{assert.equal((await updater.check()).phase,'available');assert.equal((await updater.download()).phase,'ready');assert.ok(updater.file.endsWith('.AppImage'));await updater.install();assert.equal(runs,1);}finally{await fs.rm(dir,{recursive:true,force:true});}
});
test('AppImage replacement verifies copied bytes and restores previous file on spawn failure',async()=>{
 const dir=await fs.mkdtemp(path.join(os.tmpdir(),'max-linux-install-')),source=path.join(dir,'new'),target=path.join(dir,'Max.AppImage');const payload=Buffer.from('new-version'),manifest={size:payload.length,sha512:crypto.createHash('sha512').update(payload).digest('hex')};
 try{
  await fs.writeFile(source,payload);await fs.writeFile(target,'old-version');
  await assert.rejects(installAppImage(source,target,{...manifest,sha512:'0'.repeat(128)}),/válida/);assert.equal(await fs.readFile(target,'utf8'),'old-version');
  await assert.rejects(installAppImage(source,target,manifest,{spawnProcess:()=>{const child=new EventEmitter();queueMicrotask(()=>child.emit('error',Error('spawn failed')));return child;}}),/spawn failed/);assert.equal(await fs.readFile(target,'utf8'),'old-version');
  await installAppImage(source,target,manifest,{spawnProcess:()=>{const child=new EventEmitter();child.unref=()=>{};queueMicrotask(()=>child.emit('spawn'));return child;}});assert.equal(await fs.readFile(target,'utf8'),'new-version');
 }finally{await fs.rm(dir,{recursive:true,force:true});}
});
