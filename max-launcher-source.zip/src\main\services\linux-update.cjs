'use strict';
const fs=require('node:fs/promises');
const {createReadStream}=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const {spawn}=require('node:child_process');
async function digest(file){const h=crypto.createHash('sha512');for await(const bytes of createReadStream(file))h.update(bytes);return h.digest('hex');}
async function installAppImage(source,target,manifest,{spawnProcess=spawn}={}){
 if(!target||!path.isAbsolute(target)||!target.endsWith('.AppImage'))throw Error('Ejecuta el AppImage desde una carpeta con permisos de escritura.');
 const stat=await fs.lstat(target);if(!stat.isFile()||stat.isSymbolicLink())throw Error('AppImage de destino no válido.');
 await fs.access(path.dirname(target),2);
 const staging=target+'.update-'+crypto.randomUUID(),backup=target+'.previous';let replaced=false;
 try{
  await fs.copyFile(source,staging,1);
  if((await fs.stat(staging)).size!==manifest.size||await digest(staging)!==manifest.sha512)throw Error('La actualización copiada no es válida.');
  await fs.chmod(staging,0o700);
  // Keep a complete rollback image; rename atomically swaps the running file on Linux.
  await fs.copyFile(target,backup,1);await fs.chmod(backup,0o700);
  await fs.rename(staging,target);replaced=true;
  const env={...process.env};for(const key of ['APPIMAGE','APPDIR','ARGV0','OWD'])delete env[key];
  await new Promise((resolve,reject)=>{const child=spawnProcess(target,[],{detached:true,stdio:'ignore',shell:false,env});child.once('error',reject);child.once('spawn',()=>{child.unref();resolve();});});
  await fs.unlink(backup).catch(()=>{});
 }catch(error){if(replaced)await fs.rename(backup,target);throw error;}
 finally{await fs.unlink(staging).catch(()=>{});}
}
module.exports={installAppImage};
