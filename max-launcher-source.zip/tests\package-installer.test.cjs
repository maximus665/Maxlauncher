const {test}=require('node:test');const assert=require('node:assert/strict');
const fs=require('fs/promises');const os=require('os');const path=require('path');
const {extract,safeTarget,installPackage}=require('../src/main/services/package-installer.cjs');
test('rejects traversal, absolute paths, alternate streams and Windows reserved names',()=>{
 const root=path.resolve('test-instance');for(const name of ['../escape','/escape','C:/escape','mods/evil:stream','mods/NUL.jar','mods/file.','mods\\escape'])assert.throws(()=>safeTarget(root,name),/Ruta/);
 assert.equal(safeTarget(root,'mods/example.jar'),path.join(root,'mods','example.jar'));
});
function crc32(buffer){let crc=0xffffffff;for(const byte of buffer){crc^=byte;for(let i=0;i<8;i++)crc=(crc>>>1)^((crc&1)?0xedb88320:0)}return (crc^0xffffffff)>>>0}
function zipEntry(name,content){const n=Buffer.from(name),b=Buffer.from(content),crc=crc32(b);const local=Buffer.alloc(30),central=Buffer.alloc(46),end=Buffer.alloc(22);local.writeUInt32LE(0x04034b50);local.writeUInt16LE(20,4);local.writeUInt32LE(crc,14);local.writeUInt32LE(b.length,18);local.writeUInt32LE(b.length,22);local.writeUInt16LE(n.length,26);central.writeUInt32LE(0x02014b50);central.writeUInt16LE(20,4);central.writeUInt16LE(20,6);central.writeUInt32LE(crc,16);central.writeUInt32LE(b.length,20);central.writeUInt32LE(b.length,24);central.writeUInt16LE(n.length,28);end.writeUInt32LE(0x06054b50);end.writeUInt16LE(1,8);end.writeUInt16LE(1,10);end.writeUInt32LE(central.length+n.length,12);end.writeUInt32LE(local.length+n.length+b.length,16);return Buffer.concat([local,n,b,central,n,end])}
test('extracts a real ZIP and rejects an unsafe ZIP entry',async()=>{
 const temp=await fs.mkdtemp(path.join(os.tmpdir(),'maxmax-zip-test-'));try{
  const zip=path.join(temp,'package.zip'),target=path.join(temp,'client');await fs.mkdir(target);
  await fs.writeFile(zip,zipEntry('config/options.txt','server configured'));await extract(zip,target);assert.equal(await fs.readFile(path.join(target,'config/options.txt'),'utf8'),'server configured');
  await fs.writeFile(zip,zipEntry('../escape.txt','unsafe'));await assert.rejects(extract(zip,target));
 }finally{await fs.rm(temp,{recursive:true,force:true})}
});
test('downloads, verifies and installs ZIP; a corrupt update preserves existing client',async()=>{
 const crypto=require('crypto');const oldFetch=global.fetch;
 const temp=await fs.mkdtemp(path.join(os.tmpdir(),'maxmax-install-test-'));try{
  const root=path.join(temp,'client');const manifest={schemaVersion:1,launch:{mainClass:'example.Main',classpath:['launcher.json']}};
  const bytes=zipEntry('launcher.json',JSON.stringify(manifest));const hash=crypto.createHash('sha256').update(bytes).digest('hex');
  global.fetch=async()=>new Response(bytes,{status:200});
  const result=await installPackage({url:'https://example.com/client.zip',sha256:hash,root,validate:value=>assert.equal(value.schemaVersion,1),progress:{}});
  assert.equal(result.launch.mainClass,'example.Main');assert.equal(await fs.readFile(path.join(root,'.installed-package.sha256'),'utf8'),hash);
  await assert.rejects(installPackage({url:'https://example.com/client.zip',sha256:'0'.repeat(64),root,validate:()=>{},progress:{}}),/SHA/);
  assert.equal(JSON.parse(await fs.readFile(path.join(root,'launcher.json'),'utf8')).launch.mainClass,'example.Main');
 }finally{global.fetch=oldFetch;await fs.rm(temp,{recursive:true,force:true})}
});
