const {test}=require('node:test');const assert=require('node:assert/strict');
const {UpdateDistribution}=require('../src/main/services/update-distribution.cjs');
test('only owner may distribute even if administrator has a verified candidate',async()=>{
 let writes=0;const accounts={me:async()=>({profile:{role:'admin'}}),publishLauncherVersion:async()=>writes++};
 const service=new UpdateDistribution({},accounts,{});service.candidate={version:'0.3.1',expiresAt:new Date(Date.now()+60000).toISOString()};
 await assert.rejects(service.publish('0.3.1'),/dueño/);assert.equal(writes,0);
});
test('unapproved GitHub releases are not queried or downloaded',async()=>{
 let checks=0,downloads=0;const updater={currentVersion:'0.3.0',state:{phase:'idle'},installed:true,check:async()=>checks++,download:async()=>downloads++,status(){return this.state}};
 const service=new UpdateDistribution(updater,{updateChannel:async()=>({version:null})},{});
 await service.tick();assert.equal(checks,0);assert.equal(downloads,0);
});
test('approved version is checked exactly and downloads without installing',async()=>{
 let checks=[],downloads=0;const updater={currentVersion:'0.3.0',state:{phase:'idle'},installed:true,check:async version=>{checks.push(version);updater.state.phase='available'},download:async()=>{downloads++},status(){return this.state}};
 const service=new UpdateDistribution(updater,{updateChannel:async()=>({version:'0.3.1'})},{});
 await service.tick();assert.deepEqual(checks,['0.3.1']);assert.equal(downloads,1);
});
test('ordinary accounts cannot inspect administration',async()=>{
 const service=new UpdateDistribution({},{me:async()=>({profile:{role:'player'}})},{});
 await assert.rejects(service.adminStatus(),/denegado/);await assert.rejects(service.inspect(),/denegado/);
});
