const fs = require('fs/promises');
const path = require('path');
const { safeStorage } = require('electron');
const { ImageStorage } = require('./image-storage.cjs');

class SupabaseService {
  constructor(userData) { this.userData = userData; this.session = null; this.sessionLoaded = false; this.images = new ImageStorage(this); }
  configPath() { return path.join(this.userData(), 'supabase.config.json'); }
  sessionPath() { return path.join(this.userData(), 'session.dat'); }
  async config() { try { return JSON.parse(await fs.readFile(this.configPath(), 'utf8')); } catch { try { return JSON.parse(await fs.readFile(path.resolve(__dirname, '../../../config/supabase.config.json'), 'utf8')); } catch { return null; } } }
  async saveConfig(config) { if (!/^https:\/\/[a-z0-9-]+\.supabase\.co$/i.test(config?.url || '') || !config?.publishableKey) throw Error('La configuración de Supabase no es válida.'); await fs.mkdir(this.userData(), { recursive: true }); await fs.writeFile(this.configPath(), JSON.stringify(config), 'utf8'); return { configured: true }; }
  secureStorage() { return safeStorage.isEncryptionAvailable() && !(process.platform==='linux' && safeStorage.getSelectedStorageBackend?.()==='basic_text'); }
  async loadSession() { if (this.sessionLoaded) return; this.sessionLoaded = true; try { if (!this.secureStorage()) return; this.session = JSON.parse(safeStorage.decryptString(await fs.readFile(this.sessionPath()))); } catch { this.session = null; } }
  async saveSession() { if (!this.session || !this.secureStorage()) return; await fs.mkdir(this.userData(), { recursive: true }); await fs.writeFile(this.sessionPath(), safeStorage.encryptString(JSON.stringify(this.session)),{mode:0o600}); }
  async clearSession() { this.session = null; await fs.rm(this.sessionPath(), { force: true }).catch(() => {}); }
  async refreshSession() { const cfg = await this.config(); if (!cfg || !this.session?.refresh_token) return false; const response = await fetch(`${cfg.url}/auth/v1/token?grant_type=refresh_token`, { method: 'POST', headers: { apikey: cfg.publishableKey, 'Content-Type': 'application/json' }, body: JSON.stringify({ refresh_token: this.session.refresh_token }) }); if (!response.ok) { await this.clearSession(); return false; } this.session = await response.json(); await this.saveSession(); return true; }
  async activeSession() { await this.loadSession(); if (!this.session) return null; const expiry = Number(this.session.expires_at || 0) * 1000; if (expiry && expiry - Date.now() < 60_000 && !(await this.refreshSession())) return null; return this.session; }
  async request(route, options = {}, authenticated = false) { const cfg = await this.config(); if (!cfg) throw Error('El servicio de cuentas no está disponible.'); const session = authenticated ? await this.activeSession() : this.session; if (authenticated && !session) throw Error('Tu sesión expiró. Inicia sesión nuevamente.'); const headers = { apikey: cfg.publishableKey, 'Content-Type': 'application/json', ...(options.headers || {}) }; if (session?.access_token) headers.Authorization = `Bearer ${session.access_token}`; const response = await fetch(`${cfg.url}${route}`, { ...options, headers }); const body = await response.json().catch(() => null); if (!response.ok) throw Error(body?.msg || body?.message || body?.error_description || 'No fue posible contactar al servicio de cuentas.'); return body; }
  async signUp(email, password, username) { const result = await this.request('/auth/v1/signup', { method: 'POST', body: JSON.stringify({ email, password, data: { username } }) }); this.sessionLoaded = true; this.session = result.session || (result.access_token ? result : null); if (this.session) await this.saveSession(); return { needsConfirmation: !this.session, user: result.user }; }
  async signIn(email, password) { this.session = await this.request('/auth/v1/token?grant_type=password', { method: 'POST', body: JSON.stringify({ email, password }) }); await this.saveSession(); return this.me(); }
  async signOut() { await this.clearSession(); return { ok: true }; }
  async updateChannel() {
    const cfg=await this.config();if(!cfg)throw Error('Servicio de actualizaciones no disponible.');
    const response=await fetch(`${cfg.url}/rest/v1/launcher_update_channel?select=version,published_at&id=eq.1`,{headers:{apikey:cfg.publishableKey},signal:AbortSignal.timeout(15000)});
    if(!response.ok)throw Error('No se pudo consultar el canal de actualizaciones.');
    const rows=await response.json();return rows[0] || {version:null,published_at:null};
  }
  async publishLauncherVersion(version) {
    const account=await this.me();if(account.profile?.role!=='owner')throw Error('Solo el dueño puede distribuir actualizaciones.');
    if(!/^\d{1,8}\.\d{1,8}\.\d{1,8}$/.test(version))throw Error('Versión no válida.');
    return this.request('/rest/v1/rpc/publish_launcher_version',{method:'POST',body:JSON.stringify({new_version:version})},true);
  }
  async me() {
    const session=await this.activeSession();if(!session)return {user:null,profile:null};
    const result=await this.request('/rest/v1/rpc/launcher_my_profile',{method:'POST',body:'{}'},true);
    const profile=Array.isArray(result)?result[0]:result;
    if(profile?.is_banned){await this.clearSession();throw Error('Cuenta suspendida. BAN_INFO:'+JSON.stringify({reason:profile.ban_public_reason||'Incumplimiento de las normas de la comunidad.',expiresAt:profile.ban_expires_at||null}));}
    return {user:{email:session.user.email,id:session.user.id},profile:profile||null};
  }
  instanceSelect() { return 'id,slug,name,description,manifest_url,package_url,package_sha256,image_url,banner_url,min_role,minecraft_version,loader,loader_version,instance_version,status,availability_start,availability_end,is_published,created_at,updated_at,created_by,creator:profiles!instances_created_by_fkey(username,avatar_url,role,is_verified,verified_at,role_since)'; }
  async instances() { if (!(await this.activeSession())) return []; return this.request(`/rest/v1/instances?select=${this.instanceSelect()}&is_published=eq.true&order=created_at.desc`, {}, true); }
  async managedInstances() { const account = await this.me(); if (!account.profile || !['admin', 'owner'].includes(account.profile.role)) throw Error('No tienes permiso para administrar instancias.'); return this.request(`/rest/v1/instances?select=${this.instanceSelect()}&order=updated_at.desc`, {}, true); }
  async users(query = '') {
    if (!(await this.activeSession())) return [];
    const term = String(query).trim().replace(/[^A-Za-z0-9_]/g, '').slice(0, 16);
    return this.request('/rest/v1/rpc/launcher_public_profiles',{method:'POST',body:JSON.stringify({search_query:term})},true);
  }
  async updateProfile({ bio, avatarUrl, bannerUrl }) {
    const previous = (await this.me()).profile;
    const result = await this.request('/rest/v1/rpc/update_my_profile', { method: 'POST', body: JSON.stringify({ new_avatar_url: avatarUrl || null, new_bio: typeof bio === 'string' ? bio : null, new_banner_url: bannerUrl || null }) }, true);
    const profile = Array.isArray(result) ? result[0] : result;
    for (const url of new Set([previous?.avatar_url, previous?.banner_url].filter(Boolean))) {
      if (url !== profile?.avatar_url && url !== profile?.banner_url) await this.images.retire(url).catch(() => {});
    }
    return profile;
  }
  async uploadImage(dataUrl, bucket) { return this.images.upload(dataUrl, bucket); }
  async createInstance(input) {
    const account = await this.me();
    if (!account.profile || !['admin', 'owner'].includes(account.profile.role)) throw Error('Solo el dueño o un administrador pueden publicar instancias.');
    const slug = String(input.slug || '').toLowerCase().trim();
    const name = String(input.name || '').trim();
    const manifestUrl = String(input.manifest_url || '').trim();
    if (!/^[a-z0-9-]{3,48}$/.test(slug) || name.length < 3 || name.length > 80 || (manifestUrl && !/^https:\/\//.test(manifestUrl))) throw Error('Revisa el nombre, identificador y enlace HTTPS.');
    const row = this.instancePayload(input, { created_by: account.user.id });
    const result = await this.request('/rest/v1/instances', { method: 'POST', headers: { Prefer: 'return=representation' }, body: JSON.stringify(row) }, true);
    return result[0] || result;
  }
  instancePayload(input, extra = {}) {
    const packageUrl = String(input.package_url || '').trim();
    const packageHash = String(input.package_sha256 || '').trim().toLowerCase();
    if (packageUrl && (!/^https:\/\//.test(packageUrl) || !/^[a-f0-9]{64}$/.test(packageHash))) throw Error('El paquete requiere un enlace HTTPS y un SHA-256 válido.');
    const date = (value) => value ? new Date(value).toISOString() : null;
    const start = date(input.availability_start); const end = date(input.availability_end);
    if (start && end && end <= start) throw Error('La fecha de fin debe ser posterior al inicio.');
    return { ...extra, slug: String(input.slug || '').toLowerCase().trim(), name: String(input.name || '').trim(), description: String(input.description || '').trim().slice(0, 500), manifest_url: String(input.manifest_url || '').trim() || null, package_url: packageUrl || null, package_sha256: packageUrl ? packageHash : null, image_url: input.image_url || null, banner_url: input.banner_url || input.image_url || null, minecraft_version: input.minecraft_version || null, loader: input.loader || null, instance_version: input.instance_version || null, min_role: ['player', 'moderator', 'admin', 'owner'].includes(input.min_role) ? input.min_role : 'player', status: ['online', 'maintenance', 'archived'].includes(input.status) ? input.status : 'online', is_published: Boolean(input.is_published), availability_start: start, availability_end: end, updated_at: new Date().toISOString() };
  }
  async updateInstance(id, input) {
    const account = await this.me(); if (!account.profile || !['admin', 'owner'].includes(account.profile.role)) throw Error('No tienes permiso para editar instancias.');
    if (!/^[0-9a-f-]{36}$/i.test(String(id || ''))) throw Error('Instancia no válida.');
    const row = this.instancePayload(input); if (!/^[a-z0-9-]{3,48}$/.test(row.slug) || row.name.length < 3 || row.name.length > 80 || (row.manifest_url && !/^https:\/\//.test(row.manifest_url))) throw Error('Revisa el nombre, identificador y enlace HTTPS.');
    const previous = await this.request(`/rest/v1/instances?select=image_url,banner_url&id=eq.${encodeURIComponent(id)}`, {}, true);
    const result = await this.request(`/rest/v1/instances?id=eq.${encodeURIComponent(id)}`, { method: 'PATCH', headers: { Prefer: 'return=representation' }, body: JSON.stringify(row) }, true);
    if (!result[0]) throw Error('Instancia no encontrada.');
    for (const url of new Set([previous[0]?.image_url, previous[0]?.banner_url].filter(Boolean))) {
      if (url !== row.image_url && url !== row.banner_url) await this.deleteManagedImage(url).catch(() => {});
    }
    return result[0];
  }
  async deleteInstance(id) {
    const account = await this.me(); if (!account.profile || !['admin', 'owner'].includes(account.profile.role)) throw Error('No tienes permiso para eliminar instancias.');
    if (!/^[0-9a-f-]{36}$/i.test(String(id || ''))) throw Error('Instancia no válida.');
    const rows = await this.request(`/rest/v1/instances?select=image_url,banner_url&id=eq.${encodeURIComponent(id)}`, {}, true); const row = rows[0];
    if (!row) throw Error('Instancia no encontrada.');
    await this.request(`/rest/v1/instances?id=eq.${encodeURIComponent(id)}`, { method: 'DELETE' }, true);
    let cleanupPending = false;
    for (const imageUrl of new Set([row?.image_url, row?.banner_url].filter(Boolean))) {
      try { await this.deleteManagedImage(imageUrl); } catch { cleanupPending = true; }
    }
    return { deleted: true, cleanupPending };
  }
  async deleteManagedImage(publicUrl) {
    try { await this.images.remove(publicUrl); }
    catch (error) { await this.images.defer(publicUrl).catch(() => {}); throw error; }
  }
  async userDetail(id) {
    if(!(await this.activeSession()))throw Error('Inicia sesión.');
    if(!/^[0-9a-f-]{36}$/i.test(String(id)))throw Error('Usuario no válido.');
    const profiles=await this.request('/rest/v1/rpc/launcher_public_profiles',{method:'POST',body:JSON.stringify({target_id:id})},true);
    const profile=profiles[0]||null;
    const instances=profile?.is_banned?[]:await this.request(`/rest/v1/instances?select=${this.instanceSelect()}&created_by=eq.${encodeURIComponent(id)}&is_published=eq.true&order=created_at.desc`,{},true);
    return {profile,instances};
  }
  async managePermissions({ userId, role, verified }) {
    const account = await this.me();
    if (account.profile?.role !== 'owner') throw Error('Solo el dueño puede cambiar permisos.');
    if(userId===account.user?.id && role!=='owner')throw Error('No puedes quitarte el rol de dueño.');
    if (!/^[0-9a-f-]{36}$/i.test(String(userId || '')) || !['player', 'moderator', 'admin', 'owner'].includes(role)) throw Error('Los datos de permisos no son válidos.');
    const result = await this.request('/rest/v1/rpc/manage_user_permissions', { method: 'POST', body: JSON.stringify({ target_id: userId, new_role: role, verified: Boolean(verified) }) }, true);
    return Array.isArray(result) ? result[0] : result;
  }
  async manageBan({userId,banned,reason='',expiresAt=null}) {
    const account=await this.me();if(!['owner','admin','moderator'].includes(account.profile?.role))throw Error('Solo el dueño, administrador o moderador puede gestionar baneos.');
    if(userId===account.user?.id)throw Error('La cuenta del dueño está protegida.');
    if(!/^[0-9a-f-]{36}$/i.test(String(userId||'')) || typeof banned!=='boolean' || typeof reason!=='string' || reason.length>500 || (banned && reason.trim().length<3))throw Error('Datos de baneo no válidos.');
    if(expiresAt!==null && (typeof expiresAt!=='string' || !Number.isFinite(Date.parse(expiresAt)) || Date.parse(expiresAt)<=Date.now() || Date.parse(expiresAt)>Date.now()+365*86400000))throw Error('Duración de baneo no válida.');
    return this.request('/rest/v1/rpc/moderate_launcher_user',{method:'POST',body:JSON.stringify({target_id:userId,ban_enabled:banned,public_reason:reason.trim(),expires_at:expiresAt})},true);
  }
}
module.exports = { SupabaseService };
