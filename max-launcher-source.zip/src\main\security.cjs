const {pathToFileURL}=require('url');
function blockedShortcut(input){
 const key=String(input.key||'').toLowerCase();const modifier=input.control||input.meta;
 return key==='f12'||(modifier&&input.shift&&['i','j','c'].includes(key))||(modifier&&['u','r'].includes(key))||key==='f5';
}
function secureWindow(win,file){
 const allowed=pathToFileURL(file).href;
 win.removeMenu();win.setMenuBarVisibility(false);
 win.webContents.setWindowOpenHandler(()=>({action:'deny'}));
 win.webContents.on('will-navigate',(event,url)=>{if(url!==allowed)event.preventDefault()});
 win.webContents.on('will-attach-webview',event=>event.preventDefault());
 win.webContents.on('before-input-event',(event,input)=>{if(blockedShortcut(input))event.preventDefault()});
 win.webContents.on('devtools-opened',()=>win.webContents.closeDevTools());
 win.webContents.on('context-menu',event=>event.preventDefault());
 win.webContents.session.setPermissionRequestHandler((_wc,_permission,callback)=>callback(false));
 win.webContents.session.setPermissionCheckHandler(()=>false);
}
function trustedSender(event,file){
 return Boolean(event.senderFrame && !event.senderFrame.parent && event.senderFrame.url===pathToFileURL(file).href);
}
function externalUrl(value){
 const url=new URL(value);
 if(url.protocol!=='https:'||url.username||url.password)throw Error('Enlace no permitido.');
 return url.href;
}
function windowPreferences(preload){return {preload,contextIsolation:true,nodeIntegration:false,sandbox:true,devTools:false,webSecurity:true,webviewTag:false};}
module.exports={blockedShortcut,secureWindow,trustedSender,externalUrl,windowPreferences};
