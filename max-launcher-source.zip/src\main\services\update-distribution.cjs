'use strict';
const {LauncherUpdates}=require('./launcher-updates.cjs');
const {compareVersions}=require('./update-policy.cjs');
class UpdateDistribution {
  constructor(updater,accounts,probeOptions){this.updater=updater;this.accounts=accounts;this.probeOptions=probeOptions;this.busy=false;this.candidate=null;this.checkedAt=0;}
  async staff(){const account=await this.accounts.me();if(!['admin','owner'].includes(account.profile?.role))throw Error('Acceso denegado.');}
  async check(){
    const channel=await this.accounts.updateChannel();
    if(channel?.version && compareVersions(channel.version,this.updater.currentVersion)>0)await this.updater.check(channel.version);
    else if(!this.updater.manifest && !this.updater.busy)this.updater.state={phase:'current',version:this.updater.currentVersion,progress:0,message:''};
    return this.updater.status();
  }
  async tick(){
    if(this.busy)return;this.busy=true;
    try {
      if(this.updater.state.phase==='waiting')await this.updater.retry();
      else {await this.check();if(this.updater.installed && this.updater.state.phase==='available')await this.updater.download();}
    } finally{this.busy=false;}
  }
  async adminStatus(){await this.staff();return {currentVersion:this.updater.currentVersion,candidate:this.candidate,channel:await this.accounts.updateChannel()};}
  async inspect(){
    await this.staff();
    if(this.inspectBusy)throw Error('La comprobación está en curso.');
    if(Date.now()-this.checkedAt<10000)return this.adminStatus();
    this.inspectBusy=true;this.checkedAt=Date.now();this.candidate=null;
    try {
      const probe=new LauncherUpdates({...this.probeOptions,currentVersion:'0.0.0',platform:this.probeOptions.platforms?.[0]||'win32-x64'});
      const result=await probe.check();
      if(result.phase==='error')throw Error(result.message);
      if(result.phase==='available'){
       const manifests=[probe.manifest];
       for(const platform of (this.probeOptions.platforms||[]).slice(1)){
        const other=new LauncherUpdates({...this.probeOptions,currentVersion:'0.0.0',platform,userData:()=>this.probeOptions.userData()+'-'+platform});
        if((await other.check(probe.manifest.version)).phase!=='available')throw Error('Falta una actualización firmada para '+platform+'.');
        manifests.push(other.manifest);
       }
       this.candidate={version:probe.manifest.version,size:probe.manifest.size,expiresAt:new Date(Math.min(...manifests.map(m=>Date.parse(m.expiresAt)))).toISOString()};
      }
      return this.adminStatus();
    }finally{this.inspectBusy=false;}
  }
  async publish(version){
    const account=await this.accounts.me();if(account.profile?.role!=='owner')throw Error('Solo el dueño puede distribuir actualizaciones.');
    if(!this.candidate || this.candidate.version!==version || Date.parse(this.candidate.expiresAt)<=Date.now())throw Error('Comprueba una publicación firmada antes de distribuirla.');
    await this.accounts.publishLauncherVersion(version);
    void this.tick().catch(()=>{});
    return this.adminStatus();
  }
}
module.exports={UpdateDistribution};
