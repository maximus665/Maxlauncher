const fs = require('fs/promises');
const path = require('path');
const crypto = require('crypto');

class ImageStorage {
  constructor(service) {
    this.service = service; this.inflight = new Map(); this.recent = new Map();
    this.tail = Promise.resolve(); this.cleaning = null; this.lastSweep = 0; this.leases = new Map();
  }
  async upload(dataUrl, bucket) {
    const session = await this.service.activeSession();
    if (!session) throw Error('Inicia sesión para subir una imagen.');
    if (!['avatars', 'instance-images'].includes(bucket)) throw Error('Destino de imagen no permitido.');
    if (bucket === 'instance-images' && !['admin', 'owner'].includes((await this.service.me()).profile?.role)) throw Error('Acceso denegado.');
    const match = /^data:(image\/(?:png|jpeg|webp));base64,([A-Za-z0-9+/=]+)$/.exec(String(dataUrl || ''));
    if (!match) throw Error('Elige una imagen PNG, JPG o WEBP válida.');
    const bytes = Buffer.from(match[2], 'base64');
    if (!bytes.length || bytes.length > 5 * 1024 * 1024) throw Error('La imagen debe pesar como máximo 5 MB.');
    const ext = match[1] === 'image/jpeg' ? 'jpg' : match[1].split('/')[1];
    const digest = crypto.createHash('sha256').update(bytes).digest('hex');
    const name = `${session.user.id}/${digest}.${ext}`;
    const key = `${bucket}/${name}`;
    if (this.inflight.has(key)) return this.inflight.get(key);
    const promise = this.uploadOnce({session, bucket, bytes, type: match[1], name});
    this.inflight.set(key, promise);
    try { return await promise; } finally { this.inflight.delete(key); }
  }
  async uploadOnce({session, bucket, bytes, type, name}) {
    const cfg = await this.service.config();
    const url = `${cfg.url}/storage/v1/object/public/${bucket}/${name}`;
    this.leases.set(url, Date.now() + 300000);
    const headers = { apikey: cfg.publishableKey, Authorization: `Bearer ${session.access_token}` };
    const exists = await fetch(url, {method: 'HEAD', headers, signal: AbortSignal.timeout(15000)});
    if (exists.ok) return url;
    if (exists.status !== 404 && exists.status !== 400) throw Error('No se pudo comprobar la imagen.');
    const rateKey = `${session.user.id}/${bucket}`;
    const now = Date.now(); const recent = (this.recent.get(rateKey) || []).filter(time => now - time < 5000);
    if (recent.length >= 2) throw Error(`Espera ${Math.ceil((5000 - (now - recent[0])) / 1000)} segundos antes de subir otra imagen.`);
    recent.push(now); this.recent.set(rateKey, recent);
    const response = await fetch(`${cfg.url}/storage/v1/object/${bucket}/${name}`, {method: 'POST', headers: {...headers, 'Content-Type': type, 'x-upsert': 'false'}, body: bytes, signal: AbortSignal.timeout(60000)});
    if (!response.ok) {
      const body = await response.json().catch(() => null);
      if (response.status !== 409 && String(body?.statusCode) !== '409' && body?.error !== 'Duplicate') throw Error(body?.message || 'No fue posible subir la imagen.');
      const check = await fetch(url, {method: 'HEAD', headers, signal: AbortSignal.timeout(15000)});
      if (!check.ok) throw Error('No se pudo confirmar la subida de la imagen.');
    }
    // A crash or abandoned save leaves a durable candidate, not a permanent orphan.
    await this.defer(url, 300000);
    return url;
  }
  async locate(url) {
    const cfg = await this.service.config();
    for (const bucket of ['avatars', 'instance-images']) {
      const prefix = `${cfg.url}/storage/v1/object/public/${bucket}/`;
      if (!String(url).startsWith(prefix)) continue;
      const name = decodeURIComponent(url.slice(prefix.length));
      if (!name || name.includes('..') || name.includes('?') || name.includes('#') || name.includes('\\')) throw Error('Ruta de imagen no válida.');
      return {cfg, bucket, name};
    }
    return null;
  }
  async remove(url) {
    if ((this.leases.get(url) || 0) > Date.now()) throw Error('Imagen en proceso de guardado.');
    this.leases.delete(url);
    const location = await this.locate(url); if (!location) return;
    const {cfg, bucket, name} = location;
    const session = await this.service.activeSession(); if (!session) throw Error('Inicia sesión.');
    if (bucket === 'avatars' && name.split('/')[0] !== session.user?.id) throw Error('Acceso denegado.');
    if (bucket === 'instance-images' && !['admin', 'owner'].includes((await this.service.me()).profile?.role)) throw Error('Acceso denegado.');
    const referenced = await this.service.request('/rest/v1/rpc/is_launcher_image_referenced', {method: 'POST', body: JSON.stringify({image_url: url})}, true);
    if (typeof referenced !== 'boolean') throw Error('No se pudo comprobar el uso de la imagen.');
    if (referenced) return;
    const response = await fetch(`${cfg.url}/storage/v1/object/${bucket}`, {method: 'DELETE', headers: {apikey: cfg.publishableKey, Authorization: `Bearer ${session.access_token}`, 'Content-Type': 'application/json'}, body: JSON.stringify({prefixes: [name]}), signal: AbortSignal.timeout(15000)});
    if (!response.ok) throw Error('No se pudo limpiar la imagen.');
    const deleted = await response.json().catch(() => null);
    if (Array.isArray(deleted) && !deleted.some(object => object.name === name)) {
      const check = await fetch(url, {method: 'HEAD', signal: AbortSignal.timeout(15000)});
      if (check.status !== 404) throw Error('La imagen no se eliminó; se reintentará la limpieza.');
    }
  }
  queueFile() { return path.join(this.service.userData(), 'image-cleanup.json'); }
  mutate(fn) {
    const job = this.tail.catch(() => {}).then(async () => {
      let rows; try { rows = JSON.parse(await fs.readFile(this.queueFile(), 'utf8')); } catch { rows = []; }
      if (!Array.isArray(rows)) rows = [];
      const result = await fn(rows);
      await fs.mkdir(this.service.userData(), {recursive: true});
      const tmp = this.queueFile() + '.tmp'; await fs.writeFile(tmp, JSON.stringify(rows)); await fs.rename(tmp, this.queueFile());
      return result;
    }); this.tail = job; return job;
  }
  async defer(url, delay = 0) {
    const location = await this.locate(url); if (!location) return;
    const session = await this.service.activeSession(); if (!session) return;
    if (location.bucket === 'avatars' && location.name.split('/')[0] !== session.user.id) throw Error('Acceso denegado.');
    await this.mutate(rows => {
      const existing = rows.find(row => row.url === url && row.actor === session.user.id);
      const eligible = Date.now() + delay;
      if (existing) existing.eligible = Math.min(existing.eligible, eligible);
      else rows.push({url, actor: session.user.id, eligible, attempts: 0});
    });
  }
  async retire(url) {
    await this.defer(url); await this.clean(false);
  }
  async sweep(session) {
    if (Date.now() - this.lastSweep < 300000) return;
    this.lastSweep = Date.now();
    const cfg = await this.service.config();
    const staff = ['admin', 'owner'].includes((await this.service.me()).profile?.role);
    for (const bucket of staff ? ['avatars', 'instance-images'] : ['avatars']) {
      for (let offset = 0; offset < 10000; offset += 100) {
        const objects = await this.service.request(`/storage/v1/object/list/${bucket}`, {method: 'POST', body: JSON.stringify({prefix: session.user.id, limit: 100, offset, sortBy: {column: 'name', order: 'asc'}})}, true);
        if (!Array.isArray(objects)) throw Error('No se pudo revisar el almacenamiento.');
        for (const object of objects) {
          if (!object.id || !/^[a-zA-Z0-9._-]+$/.test(object.name) || !object.created_at || Date.now() - Date.parse(object.created_at) < 300000) continue;
          await this.defer(`${cfg.url}/storage/v1/object/public/${bucket}/${session.user.id}/${object.name}`);
        }
        if (objects.length < 100) break;
      }
    }
  }
  async clean(sweep = true) {
    if (this.cleaning) return this.cleaning;
    this.cleaning = this.cleanOnce(sweep);
    try { return await this.cleaning; } finally { this.cleaning = null; }
  }
  async cleanOnce(sweep) {
    const session = await this.service.activeSession(); if (!session) return;
    if (sweep) await this.sweep(session);
    await this.mutate(async rows => {
      const due = rows.filter(row => row.actor === session.user.id && row.eligible <= Date.now()).slice(0, 20);
      for (const row of due) {
        try { await this.remove(row.url); rows.splice(rows.indexOf(row), 1); }
        catch { row.attempts++; row.eligible = Date.now() + Math.min(300000, 10000 * 2 ** Math.min(row.attempts, 5)); }
      }
    });
  }
}
module.exports = {ImageStorage};
