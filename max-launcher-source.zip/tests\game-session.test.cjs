const {test}=require('node:test');
const assert=require('node:assert/strict');
const {EventEmitter}=require('node:events');
const {LauncherService}=require('../src/main/services/launcher-service.cjs');
function fixture() {
  const children=[];
  const service=new LauncherService(()=>process.cwd(),{spawnProcess:()=>{const child=new EventEmitter();child.unref=()=>{};children.push(child);return child;}});
  service.manifest={launch:{mainClass:'net.minecraft.client.Main',classpath:['client.jar']}};
  return {service,children};
}
test('playing starts on spawn, ends once on exit, and prevents duplicate launches',async()=>{
  const {service,children}=fixture(); let starts=0,ends=0;
  const profile={username:'Maximus',mode:'account'};
  const pending=service.launch(profile,{onStarted:()=>starts++,onEnded:()=>ends++});
  assert.equal(starts,0);
  await assert.rejects(service.launch(profile),/ya está abierto/);
  children[0].emit('spawn'); await pending; assert.equal(starts,1);
  children[0].emit('exit',0);children[0].emit('error',Error('late'));
  assert.equal(ends,1); assert.equal(service.gameChild,null);
  assert.equal((await service.status()).state,'Listo');
});
test('failed Java startup never creates a playing status or leaves a launch lock',async()=>{
  const {service,children}=fixture();let starts=0,ends=0;
  const pending=service.launch({username:'Maximus',mode:'account'},{onStarted:()=>starts++,onEnded:()=>ends++});
  children[0].emit('error',Error('Java no disponible'));
  await assert.rejects(pending,/Java no disponible/);
  assert.equal(starts,0);assert.equal(ends,0);assert.equal(service.gameChild,null);
});
