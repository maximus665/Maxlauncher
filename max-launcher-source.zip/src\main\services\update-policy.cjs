'use strict';
const crypto = require('node:crypto');
const APP_ID = 'studio.maxmax.launcher';
const MAX_INSTALLER = 512 * 1024 * 1024;
function versionParts(version) {
  if (typeof version !== 'string' || !/^(0|[1-9]\d{0,7})\.(0|[1-9]\d{0,7})\.(0|[1-9]\d{0,7})$/.test(version)) throw Error('Versión no válida.');
  return version.split('.').map(Number);
}
function compareVersions(a, b) {
  const aa = versionParts(a), bb = versionParts(b);
  for (let i=0;i<3;i++) if (aa[i]!==bb[i]) return aa[i]>bb[i]?1:-1;
  return 0;
}
function releaseUrl(repository, version, name) {
  if (!/^[A-Za-z0-9_-]+\/[A-Za-z0-9_.-]+$/.test(repository)) throw Error('Repositorio no válido.');
  versionParts(version);
  return `https://github.com/${repository}/releases/download/v${version}/${name}`;
}
function artifactName(version, platform) {
  versionParts(version);
  if(platform==='win32-x64')return `Max-Launcher-Setup-${version}.exe`;
  if(platform==='linux-x64')return `Max-Launcher-${version}-linux-x64.AppImage`;
  throw Error('Plataforma no compatible.');
}
function manifestName(platform, signature=false) {
  artifactName('0.0.0',platform);
  return `maxlauncher-update${platform==='linux-x64'?'-linux-x64':''}.${signature?'sig':'json'}`;
}
function verifyManifest(bytes, signature, publicKey, {repository, currentVersion, highestVersion=currentVersion, now=Date.now(),platform='win32-x64'}) {
  if (!Buffer.isBuffer(bytes) || bytes.length>16384 || !/^[A-Za-z0-9+/]{86}==$/.test(signature)) throw Error('Firma de actualización no válida.');
  let key;
  try { key=crypto.createPublicKey(publicKey); } catch { throw Error('Clave de actualización no válida.'); }
  if(key.asymmetricKeyType!=='ed25519' || !crypto.verify(null,bytes,key,Buffer.from(signature,'base64'))) throw Error('Actualización rechazada: firma no válida.');
  const manifest=JSON.parse(bytes.toString('utf8'));
  if(manifest.schemaVersion!==1 || manifest.appId!==APP_ID || manifest.repository!==repository || manifest.platform!==platform) throw Error('Actualización incompatible.');
  versionParts(manifest.version);
  if(compareVersions(manifest.version,currentVersion)<=0 || compareVersions(manifest.version,highestVersion)<0) throw Error('Versión anterior o ya instalada.');
  if(!Number.isSafeInteger(manifest.size) || manifest.size<1 || manifest.size>MAX_INSTALLER || !/^[a-f0-9]{128}$/.test(manifest.sha512)) throw Error('Integridad de actualización no válida.');
  const issued=Date.parse(manifest.issuedAt), expires=Date.parse(manifest.expiresAt);
  if(!Number.isFinite(issued) || !Number.isFinite(expires) || issued>now+300000 || expires<=now || expires<=issued || expires-issued>90*86400000) throw Error('Autorización de actualización caducada o no válida.');
  const name=artifactName(manifest.version,platform);
  if(manifest.url!==releaseUrl(repository,manifest.version,name)) throw Error('Origen de actualización no permitido.');
  return Object.freeze({...manifest});
}
module.exports={APP_ID,MAX_INSTALLER,versionParts,compareVersions,releaseUrl,verifyManifest,artifactName,manifestName};
