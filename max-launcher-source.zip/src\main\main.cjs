const { app, BrowserWindow, ipcMain, shell, Menu } = require('electron');
const path = require('path');
const fs = require('node:fs');
const { LauncherUpdates } = require('./services/launcher-updates.cjs');
const { UpdateDistribution } = require('./services/update-distribution.cjs');
const { LauncherService } = require('./services/launcher-service.cjs');
const { pingMinecraft } = require('./services/server-status.cjs');
const { SupabaseService } = require('./services/supabase-service.cjs');
const { secureWindow, trustedSender, externalUrl, windowPreferences } = require('./security.cjs');
const { DiscordPresence, readDiscordConfig } = require('./services/discord-presence.cjs');
const { DiscordContext } = require('./services/discord-context.cjs');
const uiFile = path.join(__dirname, '../../public/index.html');
function handle(channel, handler) {
  ipcMain.handle(channel, (event, ...args) => {
    if (!trustedSender(event, uiFile) || !BrowserWindow.fromWebContents(event.sender)) throw Error('Solicitud no autorizada.');
    return handler(event, ...args);
  });
}

const service = new LauncherService(() => app.getPath('userData'));
const supabase = new SupabaseService(() => app.getPath('userData'));
const discordPresence = new DiscordPresence(readDiscordConfig(path.join(__dirname, '../../config/discord.config.json')));
const discordContext = new DiscordContext(discordPresence, () => supabase.instances());
let preparedInstanceId = null;
let updates;
let clientPreparing = false;
function checkPlayable(row, account) {
  const rank = { player: 1, moderator: 2, admin: 3, owner: 4 };
  if (!row?.is_published || row.status !== 'online' || (!row.package_url && !row.manifest_url) || !account?.profile || rank[account.profile.role] < (rank[row.min_role] || 1) || (row.availability_start && Date.parse(row.availability_start) > Date.now()) || (row.availability_end && Date.parse(row.availability_end) <= Date.now())) throw Error('Instancia no disponible para jugar.');
}
function createWindow() {
  const win = new BrowserWindow({ width: 1180, height: 740, minWidth: 960, minHeight: 620, icon: path.join(__dirname, '../../public', process.platform==='linux'?'app-icon.png':'app-icon.ico'), backgroundColor: '#0b0d12', webPreferences: windowPreferences(path.join(__dirname, '../preload/index.cjs')) });
  secureWindow(win, uiFile);
  win.loadFile(uiFile);
}
app.whenReady().then(() => {
  if(process.platform==='win32')app.setAppUserModelId('studio.maxmax.launcher');
  Menu.setApplicationMenu(null);
  const updateConfig = require('../../config/updates.config.json');
  const publicKeyPath = path.join(__dirname, '../../config/update-public-key.pem');
  updates = new LauncherUpdates({repository: updateConfig.repository, publicKey: fs.existsSync(publicKeyPath) ? fs.readFileSync(publicKeyPath,'utf8') : '', currentVersion: app.getVersion(), userData: () => app.getPath('userData'), installed: app.isPackaged && (process.platform==='linux'?Boolean(process.env.APPIMAGE):fs.existsSync(path.join(path.dirname(process.execPath), 'Uninstall Max Launcher.exe'))), gameRunning: () => Boolean(service.gameChild || clientPreparing), quit: () => app.quit()});
  const distribution = new UpdateDistribution(updates, supabase, {repository:updateConfig.repository,publicKey:updates.publicKey,userData:()=>path.join(app.getPath('userData'),'release-inspection'),platforms:['win32-x64','linux-x64']});
  handle('updates:status', () => updates.status());
  handle('updates:check', () => distribution.check());
  handle('updates:admin-status', () => distribution.adminStatus());
  handle('updates:inspect', () => distribution.inspect());
  handle('updates:publish', (_event, version) => distribution.publish(version));
  handle('updates:download', () => updates.download());
  handle('updates:install', () => updates.install());
  handle('launcher:status', () => service.status());
  handle('launcher:sync', async (_event, id) => {
    if (updates.installing || clientPreparing || service.gameChild) throw Error('Espera a que termine la operación actual.');
    clientPreparing = true;
    try {
    const account = await supabase.me();
    const rows = await supabase.instances();
    const row = rows.find(item => item.id === id);
    checkPlayable(row, account);
    preparedInstanceId = null;
    if (!row.package_url && !row.manifest_url) throw Error('Esta instancia todavía no está disponible para jugar.');
    const result = row.package_url ? await service.syncPackage(row.package_url, row.package_sha256) : await service.sync(row.manifest_url);
    preparedInstanceId = row.id;
    return result;
    } finally { clientPreparing = false; }
  });
  handle('launcher:launch', async () => {
    const account = await supabase.me();
    if (!account.user || !account.profile) throw new Error('Inicia sesión para jugar.');
    const row = (await supabase.instances()).find(item => item.id === preparedInstanceId);
    checkPlayable(row, account);
    if (updates.installing || clientPreparing) throw Error('Espera a que termine la operación actual.');
    return service.launch({ username: account.profile.username, mode: 'account' }, {
      onStarted: () => discordPresence.gameStarted(row),
      onEnded: () => discordPresence.gameEnded()
    });
  });
  handle('server:ping', async (_event, host, port) => pingMinecraft(host, port));
  handle('supabase:config', async () => ({ configured: Boolean(await supabase.config()) }));
  handle('auth:signup', (_event, data) => supabase.signUp(data.email, data.password, data.username));
  handle('auth:signin', (_event, data) => supabase.signIn(data.email, data.password));
  handle('auth:signout', () => { discordContext.select(null); return supabase.signOut(); });
  handle('discord:instance', (_event, id) => discordContext.select(id));
  handle('auth:me', () => supabase.me());
  handle('profile:update', (_event, data) => supabase.updateProfile(data));
  handle('profile:avatar', (_event, dataUrl) => supabase.uploadImage(dataUrl, 'avatars'));
  handle('community:users', (_event, query) => supabase.users(query));
  handle('community:permissions', (_event, data) => supabase.managePermissions(data));
  handle('community:ban', (_event, data) => supabase.manageBan(data));
  handle('instances:list', () => supabase.instances());
  handle('instances:create', (_event, data) => supabase.createInstance(data));
  handle('instances:manage', () => supabase.managedInstances());
  handle('instances:update', (_event, id, data) => supabase.updateInstance(id, data));
  handle('instances:delete', (_event, id) => supabase.deleteInstance(id));
  handle('instances:image', (_event, dataUrl) => supabase.uploadImage(dataUrl, 'instance-images'));
  handle('instances:cleanup-image', async (_event, url) => {
    const account = await supabase.me();
    if (!account.user) throw Error('Acceso denegado.');
    return supabase.images.defer(url, 60000);
  });
  handle('community:user-detail', (_event, id) => supabase.userDetail(id));
  handle('external:open', (_event, url) => shell.openExternal(externalUrl(url)));
  createWindow();
  discordPresence.start();
  if (app.isPackaged) {
    updates.cleanCache().catch(() => {});
    setTimeout(() => distribution.tick().catch(() => {}), 5000).unref();
    setInterval(() => distribution.tick().catch(() => {}), 15000).unref();
  }
  setTimeout(() => supabase.images.clean().catch(() => {}), 4000).unref();
  setInterval(() => supabase.images.clean().catch(() => {}), 60000).unref();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
app.on('before-quit', () => discordPresence.stop());
