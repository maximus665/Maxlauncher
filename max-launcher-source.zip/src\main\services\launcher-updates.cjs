'use strict';
const fs=require('node:fs/promises');
const path=require('node:path');
const crypto=require('node:crypto');
const {spawn}=require('node:child_process');
const {createReadStream}=require('node:fs');
const {compareVersions,releaseUrl,verifyManifest,manifestName,artifactName}=require('./update-policy.cjs');
const {installAppImage}=require('./linux-update.cjs');

async function githubFetch(url, fetcher=fetch, timeoutMs=30000) {
  let target=new URL(url);
  const allowed=new Set(['api.github.com','github.com','release-assets.githubusercontent.com','objects.githubusercontent.com']);
  for(let count=0;count<6;count++) {
    if(target.protocol!=='https:' || target.username || target.password || !allowed.has(target.hostname)) throw Error('Origen de descarga no permitido.');
    // Release metadata is JSON; only release assets use the binary media type.
    const headers={'User-Agent':'Max-Launcher-Updater','Accept':target.hostname==='api.github.com'?'application/vnd.github+json':'application/octet-stream'};
    const response=await fetcher(target.href,{redirect:'manual',signal:AbortSignal.timeout(timeoutMs),headers});
    if([301,302,303,307,308].includes(response.status)) {
      const location=response.headers.get('location'); await response.body?.cancel();
      if(!location) throw Error('Redirección no válida.'); target=new URL(location,target); continue;
    }
    return response;
  }
  throw Error('Demasiadas redirecciones.');
}
async function limitedBytes(response,limit) {
  if(!response.ok || !response.body) throw Error('No se pudo consultar la actualización.');
  const declared=Number(response.headers.get('content-length'));
  if(declared>limit) { await response.body.cancel(); throw Error('Respuesta demasiado grande.'); }
  const chunks=[];let length=0;
  for await(const chunk of response.body) {
    length+=chunk.length;if(length>limit) throw Error('Respuesta demasiado grande.');chunks.push(Buffer.from(chunk));
  }
  return Buffer.concat(chunks);
}
async function hashFile(file) {const hash=crypto.createHash('sha512');for await(const chunk of createReadStream(file))hash.update(chunk);return hash.digest('hex');}

class LauncherUpdates {
  constructor({repository,publicKey,currentVersion,userData,installed=false,gameRunning=()=>false,fetcher=fetch,runInstaller,quit=()=>{},now=Date.now,platform=process.platform+'-'+process.arch,appImage=process.env.APPIMAGE}) {
    Object.assign(this,{repository,publicKey,currentVersion,userData,installed,gameRunning,fetcher,quit,now});
    this.platform=platform;this.appImage=appImage;
    this.runInstaller=runInstaller || (platform==='linux-x64'?file=>installAppImage(file,this.appImage,this.manifest):file=>new Promise((resolve,reject)=>{
      const child=spawn(file,['/S','--updated','--force-run'],{detached:true,stdio:'ignore',windowsHide:true,shell:false});
      child.once('spawn',()=>{child.unref();resolve();});child.once('error',reject);
    }));
    this.state={phase:'idle',version:currentVersion,progress:0,message:''};
    this.manifest=null;this.busy=false;this.lastCheck=-Infinity;this.file=null;this.installing=false;
  }
  status(){return {...this.state,installed:this.installed,canDownload:Boolean(this.manifest) && ['available','error'].includes(this.state.phase)};}
  async cleanCache() {
    const dir=path.join(this.userData(),'updates');
    const entries=await fs.readdir(dir).catch(()=>[]);
    for(const name of entries) {
      if(!/^installer-[a-f0-9-]{36}\.(exe|AppImage)$/.test(name))continue;
      const file=path.join(dir,name);if(file===this.file)continue;
      const stat=await fs.lstat(file).catch(()=>null);
      if(stat?.isFile() && !stat.isSymbolicLink() && this.now()-stat.mtimeMs>86400000)await fs.unlink(file).catch(()=>{});
    }
  }
  async highestVersion() {
    try {
      const saved=JSON.parse(await fs.readFile(path.join(this.userData(),'updates','highest-version.json'),'utf8'));
      return compareVersions(saved.version,this.currentVersion)>0?saved.version:this.currentVersion;
    }catch(error){if(error.code==='ENOENT')return this.currentVersion;throw Error('El registro local de actualizaciones no es válido.');}
  }
  async check(targetVersion) {
    if(targetVersion)compareVersions(targetVersion,this.currentVersion);
    if(this.busy || ['available','ready'].includes(this.state.phase) || this.now()-this.lastCheck<60000)return this.status();
    if(!this.publicKey){this.state.phase='disabled';this.state.message='Actualizaciones no configuradas.';return this.status();}
    this.busy=true;this.lastCheck=this.now();this.manifest=null;this.state={phase:'checking',version:this.currentVersion,progress:0,message:''};
    try {
      const response=await githubFetch(`https://api.github.com/repos/${this.repository}/releases/${targetVersion ? 'tags/v'+targetVersion : 'latest'}`,this.fetcher);
      if(response.status===404){this.state.phase='current';return this.status();}
      const release=JSON.parse((await limitedBytes(response,512*1024)).toString('utf8'));
      if(release.draft || release.prerelease || typeof release.tag_name!=='string' || !release.tag_name.startsWith('v'))throw Error('Publicación no válida.');
      const version=release.tag_name.slice(1);
      if(targetVersion && version!==targetVersion)throw Error('Versión no autorizada.');
      if(compareVersions(version,this.currentVersion)<=0){this.state.phase='current';return this.status();}
      const manifestUrl=releaseUrl(this.repository,version,manifestName(this.platform));
      const bytes=await limitedBytes(await githubFetch(manifestUrl,this.fetcher),16384);
      const signature=(await limitedBytes(await githubFetch(releaseUrl(this.repository,version,manifestName(this.platform,true)),this.fetcher),256)).toString('ascii').trim();
      const manifest=verifyManifest(bytes,signature,this.publicKey,{platform:this.platform,repository:this.repository,currentVersion:this.currentVersion,highestVersion:await this.highestVersion(),now:this.now()});
      if(manifest.version!==version)throw Error('Versión de publicación no válida.');
      const dir=path.join(this.userData(),'updates');await fs.mkdir(dir,{recursive:true});
      await fs.writeFile(path.join(dir,'highest-version.json'),JSON.stringify({version:manifest.version}));
      this.manifest=manifest;this.signedBytes=bytes;this.signature=signature;
      this.state={phase:'available',version:manifest.version,progress:0,message:''};
    }catch{this.state.phase='error';this.state.message='No se pudo verificar la actualización. No se ha instalado ningún archivo.';}
    finally{this.busy=false;}
    return this.status();
  }
  async download() {
    if(this.busy || !this.manifest || !['available','error','waiting'].includes(this.state.phase))return this.status();
    this.busy=true;this.state.phase='downloading';this.state.progress=0;this.state.message='';
    let file,handle;
    let transport=false;
    try {
      verifyManifest(this.signedBytes,this.signature,this.publicKey,{platform:this.platform,repository:this.repository,currentVersion:this.currentVersion,highestVersion:await this.highestVersion(),now:this.now()});
      const dir=path.join(this.userData(),'updates');await fs.mkdir(dir,{recursive:true});
      const extension=path.extname(artifactName(this.manifest.version,this.platform));
      file=path.join(dir,`installer-${crypto.randomUUID()}${extension}`);handle=await fs.open(file,'wx',0o600);
      transport=true;
      const response=await githubFetch(this.manifest.url,this.fetcher,300000);
      if(!response.ok || !response.body)throw Error('Descarga no disponible.');
      transport=false;
      const declared=Number(response.headers.get('content-length'));
      if(declared && declared!==this.manifest.size){await response.body.cancel();throw Error('Tamaño no válido.');}
      let size=0;const hash=crypto.createHash('sha512');
      const reader=response.body.getReader();
      try { while(true){
        transport=true;const {done,value:chunk}=await reader.read();transport=false;if(done)break;
        size+=chunk.length;if(size>this.manifest.size)throw Error('Tamaño no válido.');
        hash.update(chunk);await handle.writeFile(chunk);this.state.progress=Math.floor(size/this.manifest.size*100);
      }} finally { await reader.cancel().catch(()=>{});reader.releaseLock();
      }
      await handle.sync();await handle.close();handle=null;
      if(size!==this.manifest.size || hash.digest('hex')!==this.manifest.sha512)throw Error('Integridad no válida.');
      this.file=file;this.state.phase='ready';this.state.progress=100;
      this.retryCount=0;
    }catch{
      if(handle)await handle.close().catch(()=>{});if(file)await fs.unlink(file).catch(()=>{});
      this.state.progress=0;
      this.state.phase=transport?'waiting':'error';
      this.retryAt=this.now()+Math.min(60000,5000*2**Math.min(this.retryCount||0,4));this.retryCount=(this.retryCount||0)+1;
      this.state.message=transport?'Conexión interrumpida. Se reintentará la descarga automáticamente.':'Descarga rechazada. No se ha instalado ningún archivo.';
    }finally{this.busy=false;}
    return this.status();
  }
  async retry() {
    if(this.state.phase==='waiting' && this.now()>=this.retryAt)return this.download();
    return this.status();
  }
  async install() {
    if(this.installing || this.busy || this.state.phase!=='ready' || !this.file)throw Error('No hay una actualización verificada.');
    if(!this.installed)throw Error('La actualización requiere la versión instalada de Max Launcher.');
    if(this.gameRunning())throw Error('Cierra Minecraft antes de actualizar.');
    this.installing=true;
    try {
      verifyManifest(this.signedBytes,this.signature,this.publicKey,{platform:this.platform,repository:this.repository,currentVersion:this.currentVersion,highestVersion:await this.highestVersion(),now:this.now()});
      const stat=await fs.lstat(this.file);
      if(!stat.isFile() || stat.isSymbolicLink() || stat.size!==this.manifest.size || await hashFile(this.file)!==this.manifest.sha512)throw Error('El instalador ha cambiado.');
      if(this.gameRunning())throw Error('Cierra Minecraft antes de actualizar.');
      await this.runInstaller(this.file);this.quit();
    }catch(error){this.installing=false;this.state.phase='error';this.state.message='Instalación cancelada por seguridad.';throw error;}
  }
}
module.exports={LauncherUpdates,githubFetch,limitedBytes,hashFile};
