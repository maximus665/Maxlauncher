const fs = require('fs/promises');
const fssync = require('fs');
const path = require('path');
const crypto = require('crypto');
const { spawn } = require('child_process');
const { installPackage, safeTarget } = require('./package-installer.cjs');

class LauncherService {
  constructor(userData, options = {}) { this.userData = userData; this.manifest = null; this.progress = { state: 'Listo', completed: 0, total: 0 }; this.spawnProcess = options.spawnProcess || spawn; this.gameChild = null; }
  root() { return path.join(this.userData(), 'instances', 'maxmax-main'); }
  async status() { return { ...this.progress, manifest: this.manifest && { instance: this.manifest.instance, server: this.manifest.server } }; }
  async sync(manifestUrl) {
    if (!/^https:\/\//.test(manifestUrl)) throw new Error('El manifiesto debe usar HTTPS.');
    this.progress = { state: 'Descargando manifiesto', completed: 0, total: 0 };
    const response = await fetch(manifestUrl); if (!response.ok) throw new Error(`Manifiesto no disponible (${response.status}).`);
    const manifest = await response.json(); this.validateManifest(manifest); this.manifest = manifest;
    await fs.mkdir(this.root(), { recursive: true }); this.progress.total = manifest.files.length;
    for (const file of manifest.files) { await this.downloadIfNeeded(file); this.progress.completed++; }
    await fs.writeFile(path.join(this.root(), 'installed-manifest.json'), JSON.stringify(manifest, null, 2));
    this.progress.state = 'Cliente actualizado'; return this.status();
  }
  async syncPackage(url, sha256) {
    this.manifest = null;
    this.progress = { state: 'Preparando paquete', completed: 0, total: 0 };
    if (/^[a-f0-9]{64}$/i.test(sha256 || '')) {
      try {
        if ((await fs.readFile(path.join(this.root(), '.installed-package.sha256'), 'utf8')).trim() === sha256.toLowerCase()) {
          const installed = JSON.parse(await fs.readFile(path.join(this.root(), 'launcher.json'), 'utf8'));
          this.validateLaunch(installed);
          for (const file of installed.launch.classpath) await fs.access(safeTarget(this.root(), file));
          this.manifest = installed; this.progress.state = 'Cliente actualizado'; return this.status();
        }
      } catch { /* An incomplete local installation is repaired from the signed hash. */ }
    }
    this.manifest = await installPackage({ url, sha256, root: this.root(), progress: this.progress, validate: manifest => this.validateLaunch(manifest) });
    this.progress.state = 'Cliente actualizado';
    return this.status();
  }
  launchConfig(manifest) {
    const base=manifest?.launch;
    const launch={...base,...base?.platforms?.[process.platform]};
    if(process.platform==='linux' && /\.exe$/i.test(launch.javaPath||''))throw Error('Esta instancia necesita Java y bibliotecas para Linux.');
    return launch;
  }
  validateLaunch(manifest) {
    const launch = this.launchConfig(manifest);
    if (manifest?.schemaVersion !== 1 || !launch || !/^[A-Za-z_$][A-Za-z0-9_$.]*$/.test(launch.mainClass || '') || !Array.isArray(launch.classpath) || !launch.classpath.length) throw Error('Configuración de inicio no válida.');
    for (const file of launch.classpath) safeTarget(this.root(), file);
    for (const key of ['jvmArgs', 'gameArgs']) if (launch[key] && (!Array.isArray(launch[key]) || launch[key].some(value => typeof value !== 'string'))) throw Error('Argumentos de inicio no válidos.');
    if (launch.javaPath && launch.javaPath !== 'java') safeTarget(this.root(), launch.javaPath);
  }
  validateManifest(manifest) {
    this.validateLaunch(manifest);
    if (!Array.isArray(manifest.files)) throw new Error('Manifiesto inválido.');
    for (const item of manifest.files) if (!item.path || item.path.includes('..') || !/^https:\/\//.test(item.url) || !/^[a-f0-9]{64}$/i.test(item.sha256)) throw new Error('Archivo inseguro en manifiesto.');
  }
  async downloadIfNeeded(file) {
    const target = path.resolve(this.root(), file.path); if (!target.startsWith(path.resolve(this.root()) + path.sep)) throw new Error('Ruta fuera de la instancia.');
    if (fssync.existsSync(target) && await this.hash(target) === file.sha256.toLowerCase()) return;
    this.progress.state = `Descargando ${file.path}`; const response = await fetch(file.url); if (!response.ok) throw new Error(`No se pudo descargar ${file.path}.`);
    const bytes = Buffer.from(await response.arrayBuffer()); const digest = crypto.createHash('sha256').update(bytes).digest('hex');
    if (digest !== file.sha256.toLowerCase()) throw new Error(`Integridad inválida: ${file.path}`);
    await fs.mkdir(path.dirname(target), { recursive: true }); await fs.writeFile(target, bytes);
  }
  async hash(file) { const h = crypto.createHash('sha256'); for await (const c of fssync.createReadStream(file)) h.update(c); return h.digest('hex'); }
  async launch(profile, { onStarted = () => {}, onEnded = () => {} } = {}) {
    if (this.gameChild) throw Error('Minecraft ya está abierto.');
    if (!this.manifest) throw new Error('Actualiza el cliente antes de iniciar.');
    if (!/^[A-Za-z0-9_]{3,16}$/.test(profile?.username || '')) throw new Error('La cuenta no tiene un nombre de usuario válido.');
    if (profile.mode !== 'account') throw new Error('Inicia sesión en MaxMaxstudios para jugar.');
    const l = this.launchConfig(this.manifest), cp = (l.classpath || []).map(x => path.join(this.root(), x)).join(path.delimiter);
    const args = [...(l.jvmArgs || []), '-cp', cp, l.mainClass, ...(l.gameArgs || []).map(x => String(x).replaceAll('{username}', profile.username).replaceAll('{serverHost}', this.manifest.server?.host || '').replaceAll('{serverPort}', String(this.manifest.server?.port || 25565)))];
    const executable = l.javaPath && l.javaPath !== 'java' ? safeTarget(this.root(), l.javaPath) : 'java';
    if(process.platform==='linux' && executable!=='java'){const stat=await fs.lstat(executable);if(!stat.isFile()||stat.isSymbolicLink())throw Error('Java no válido.');await fs.chmod(executable,0o700);}
    const child = this.spawnProcess(executable, args, { cwd: this.root(), detached: true, stdio: 'ignore', windowsHide: true });
    this.gameChild = child;
    let started = false;
    const finish = () => {
      if (this.gameChild !== child) return;
      this.gameChild = null; this.progress.state = 'Listo';
      if (started) onEnded();
    };
    child.once('exit', finish);
    child.once('error', finish);
    await new Promise((resolve, reject) => {
      child.once('spawn', () => { started = true; this.progress.state = 'Juego iniciado'; onStarted(); resolve(); });
      child.once('error', reject);
    });
    child.unref(); return this.status();
  }
}
module.exports = { LauncherService };
