'use strict';

const net = require('node:net');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const { randomUUID } = require('node:crypto');
const MAX_FRAME = 1024 * 1024;
function publicImage(value) {
  try {
    const url = new URL(value);
    if (url.protocol !== 'https:' || url.username || url.password || url.href.length > 1024 || url.search || url.hash) return '';
    return url.href;
  } catch { return ''; }
}
function instanceInfo(row) {
  return row ? { name: String(row.name || 'Instancia').replace(/[\x00-\x1f\x7f]/g, '').slice(0, 110), image: publicImage(row.image_url) || publicImage(row.banner_url) } : null;
}

function readDiscordConfig(filename) {
  try {
    const config = JSON.parse(fs.readFileSync(filename, 'utf8'));
    if (config.enabled === false || typeof config.applicationId !== 'string' || !/^[1-9]\d{16,19}$/.test(config.applicationId)) return null;
    return { applicationId: config.applicationId, largeImage: /^[a-z0-9_-]{1,64}$/.test(config.largeImage || '') ? config.largeImage : '' };
  } catch { return null; }
}

function encodeFrame(opcode, payload) {
  const body = Buffer.isBuffer(payload) ? payload : Buffer.from(JSON.stringify(payload), 'utf8');
  const header = Buffer.alloc(8);
  header.writeUInt32LE(opcode, 0); header.writeUInt32LE(body.length, 4);
  return Buffer.concat([header, body]);
}

// Local IPC only: no user tokens, Discord account data, or renderer access.
class DiscordPresence {
  constructor(config, options = {}) {
    this.config = config;
    this.connect = options.connect || (pipe => net.createConnection(pipe));
    this.delay = options.delay || ((fn, ms) => setTimeout(fn, ms));
    this.cancel = options.cancel || clearTimeout;
    this.platform = options.platform || process.platform;
    this.now = options.now || Date.now;
    this.startedAt = Math.floor(this.now() / 1000);
    this.instance = null; this.game = null; this.dirty = true; this.publish = null;
    this.updateTimer = null; this.lastSentAt = -Infinity;
    this.running = false; this.socket = null; this.retryTimer = null;
    this.attemptTimer = null; this.retryMs = 5000; this.connected = false;
  }

  start() {
    if (this.running || !['win32','linux'].includes(this.platform) || typeof this.config?.applicationId !== 'string' || !/^[1-9]\d{16,19}$/.test(this.config.applicationId)) return;
    this.running = true;
    this.tryPipe(0);
  }

  timer(fn, ms) { const timer = this.delay(fn, ms); timer?.unref?.(); return timer; }

  activity() {
    const current = this.game?.instance || this.instance;
    const activity = { details: this.game ? 'Jugando Minecraft' : 'En Max Launcher', timestamps: { start: this.game?.startedAt ?? this.startedAt }, instance: false };
    if (current) activity.state = (this.game ? 'Jugando en ' : 'Viendo ') + current.name;
    const image = current?.image || this.config?.largeImage;
    if (image) activity.assets = { large_image: image, large_text: current?.name || 'Max Launcher' };
    return activity;
  }

  setInstance(row) {
    const instance = instanceInfo(row);
    if (JSON.stringify(instance) === JSON.stringify(this.instance)) return;
    this.instance = instance; this.dirty = true; this.flush();
  }

  gameStarted(row) {
    if (this.game) return;
    this.game = { instance: instanceInfo(row), startedAt: Math.floor(this.now() / 1000) };
    this.dirty = true; this.flush();
  }

  gameEnded() {
    if (!this.game) return;
    this.game = null; this.dirty = true; this.flush();
  }

  flush() {
    if (!this.running || !this.publish || !this.dirty || this.updateTimer) return;
    const wait = Math.max(0, 15000 - (this.now() - this.lastSentAt));
    if (wait) { this.updateTimer = this.timer(() => { this.updateTimer = null; this.flush(); }, wait); return; }
    this.publish();
  }

  tryPipe(index) {
    if (!this.running) return;
    if (index >= 10) { this.scheduleRetry(); return; }
    let socket;
    try { socket = this.connect(this.platform==='linux'?path.join(process.env.XDG_RUNTIME_DIR||os.tmpdir(),'discord-ipc-'+index):'\\\\?\\pipe\\discord-ipc-' + index); }
    catch { this.tryPipe(index + 1); return; }
    this.socket = socket;
    let buffer = Buffer.alloc(0); let ready = false; let done = false; let nonce;
    const fail = () => {
      if (done) return;
      done = true; this.cancel(this.attemptTimer); this.attemptTimer = null;
      this.cancel(this.updateTimer); this.updateTimer = null; this.publish = null; this.dirty = true;
      if (this.socket === socket) { this.socket = null; this.connected = false; }
      socket.destroy();
      if (this.running) { if (ready) this.scheduleRetry(); else this.tryPipe(index + 1); }
    };
    const send = (op, payload) => {
      if (done || socket.destroyed) return;
      try { socket.write(encodeFrame(op, payload)); } catch { fail(); }
    };
    socket.on('error', fail);
    socket.on('close', fail);
    socket.on('end', fail);
    this.publish = () => {
      if (nonce || !ready || done) return;
      nonce = randomUUID(); this.dirty = false; this.lastSentAt = this.now();
      this.cancel(this.attemptTimer); this.attemptTimer = this.timer(fail, 5000);
      send(1, { cmd: 'SET_ACTIVITY', args: { pid: process.pid, activity: this.activity() }, nonce });
    };
    this.attemptTimer = this.timer(fail, 5000);
    socket.once('connect', () => send(0, { v: 1, client_id: this.config.applicationId }));
    socket.on('data', chunk => {
      if (done || !this.running) return;
      if (buffer.length + chunk.length > MAX_FRAME + 8) { fail(); return; }
      buffer = Buffer.concat([buffer, chunk]);
      while (!done && buffer.length >= 8) {
        const opcode = buffer.readUInt32LE(0), size = buffer.readUInt32LE(4);
        if (size > MAX_FRAME) { fail(); return; }
        if (buffer.length < size + 8) return;
        const body = buffer.subarray(8, 8 + size); buffer = buffer.subarray(8 + size);
        if (opcode === 3) { send(4, body); continue; }
        if (opcode === 2) { fail(); return; }
        if (opcode !== 1) continue;
        let message;
        try { message = JSON.parse(body.toString('utf8')); } catch { fail(); return; }
        if (!message || typeof message !== 'object' || message.evt === 'ERROR') { fail(); return; }
        if (!ready && message.cmd === 'DISPATCH' && message.evt === 'READY') {
          ready = true;
          this.lastSentAt = -Infinity; this.dirty = true; this.flush();
        } else if (ready && nonce && message.cmd === 'SET_ACTIVITY' && message.nonce === nonce) {
          this.cancel(this.attemptTimer); this.attemptTimer = null;
          this.connected = true; this.retryMs = 5000;
          nonce = null; this.flush();
        }
      }
    });
  }

  scheduleRetry() {
    if (!this.running || this.retryTimer) return;
    this.retryTimer = this.timer(() => { this.retryTimer = null; this.tryPipe(0); }, this.retryMs);
    this.retryMs = Math.min(this.retryMs * 2, 60000);
  }

  stop() {
    this.running = false; this.connected = false;
    this.cancel(this.updateTimer); this.updateTimer = null; this.publish = null;
    this.cancel(this.retryTimer); this.cancel(this.attemptTimer);
    this.retryTimer = null; this.attemptTimer = null;
    const socket = this.socket; this.socket = null;
    if (!socket || socket.destroyed) return;
    try {
      // The server also clears activity when the process/pipe disappears.
      socket.end(encodeFrame(1, { cmd: 'SET_ACTIVITY', args: { pid: process.pid, activity: null }, nonce: randomUUID() }));
      this.timer(() => socket.destroy(), 500);
    } catch { socket.destroy(); }
  }
}

module.exports = { DiscordPresence, readDiscordConfig, encodeFrame };
