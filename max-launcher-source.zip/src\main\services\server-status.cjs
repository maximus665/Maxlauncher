const net = require('net');
function pingMinecraft(host, port = 25565) {
  return new Promise((resolve) => {
    const started = Date.now(); const socket = net.createConnection({ host, port, timeout: 3500 });
    socket.once('connect', () => { socket.destroy(); resolve({ online: true, latency: Date.now() - started }); });
    socket.once('timeout', () => { socket.destroy(); resolve({ online: false, reason: 'Tiempo de espera agotado' }); });
    socket.once('error', () => resolve({ online: false, reason: 'No se pudo conectar' }));
  });
}
module.exports = { pingMinecraft };
