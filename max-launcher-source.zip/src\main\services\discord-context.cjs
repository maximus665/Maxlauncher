'use strict';

// The renderer supplies an ID only. Names and public images come from the
// authenticated catalog, never from arbitrary renderer URLs or profile data.
class DiscordContext {
  constructor(presence, instances) { this.presence = presence; this.instances = instances; this.revision = 0; }
  async select(id) {
    const revision = ++this.revision;
    if (id == null) { this.presence.setInstance(null); return; }
    if (typeof id !== 'string' || !/^[a-f0-9]{8}-(?:[a-f0-9]{4}-){3}[a-f0-9]{12}$/i.test(id)) {
      this.presence.setInstance(null); throw Error('Instancia no válida.');
    }
    try {
      const row = (await this.instances()).find(item => item.id === id && item.is_published);
      if (revision !== this.revision) return;
      this.presence.setInstance(row || null);
    } catch (error) {
      if (revision === this.revision) this.presence.setInstance(null);
      throw error;
    }
  }
}
module.exports = { DiscordContext };
