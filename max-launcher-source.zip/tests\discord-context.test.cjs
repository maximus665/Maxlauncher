const { test } = require('node:test');
const assert = require('node:assert/strict');
const { DiscordContext } = require('../src/main/services/discord-context.cjs');
const id = '11111111-1111-1111-1111-111111111111';
const row = { id, name: 'Horizonte', is_published: true, image_url: 'https://example.com/cover.png' };
test('presence only publishes authenticated catalog records, not renderer objects or drafts', async () => {
  const selections = []; const presence = { setInstance: value => selections.push(value) };
  const context = new DiscordContext(presence, async () => [row]);
  await context.select(id); assert.deepEqual(selections.at(-1), row);
  await assert.rejects(context.select({ id, image_url: 'https://attacker.example/private' }));
  assert.equal(selections.at(-1), null);
  context.instances = async () => [{ ...row, is_published: false }];
  await context.select(id); assert.equal(selections.at(-1), null);
  context.instances = async () => []; await context.select(id); assert.equal(selections.at(-1), null);
});
test('late results cannot restore an instance after logout or leaving detail', async () => {
  let resolve; const selections = [];
  const context = new DiscordContext({ setInstance: value => selections.push(value) }, () => new Promise(r => { resolve = r; }));
  const pending = context.select(id); await context.select(null); resolve([row]); await pending;
  assert.deepEqual(selections, [null]);
});
