const {test}=require('node:test');const assert=require('node:assert/strict');
const fs=require('fs/promises');const os=require('os');const path=require('path');
const {ImageStorage}=require('../src/main/services/image-storage.cjs');
const user='11111111-1111-1111-1111-111111111111';
const url='https://example.supabase.co/storage/v1/object/public/avatars/'+user+'/old.png';
async function fixture(fn){
 const dir=await fs.mkdtemp(path.join(os.tmpdir(),'maxmax-images-'));const oldFetch=global.fetch;
 const service={userData:()=>dir,activeSession:async()=>({access_token:'test',user:{id:user}}),me:async()=>({profile:{role:'owner'}}),config:async()=>({url:'https://example.supabase.co',publishableKey:'public'}),request:async()=>false};
 try{await fn(new ImageStorage(service),service,dir)}finally{global.fetch=oldFetch;await fs.rm(dir,{recursive:true,force:true})}
}
const data=text=>'data:image/png;base64,'+Buffer.from(text).toString('base64');
test('five concurrent uploads of the same image make one POST and retries reuse the object',async()=>fixture(async images=>{
 let posts=0;const stored=new Set();global.fetch=async(u,o)=>{if(o.method==='HEAD')return new Response(null,{status:stored.has(u)?200:404});posts++;await new Promise(r=>setTimeout(r,20));stored.add(u.replace('/object/','/object/public/'));return new Response('{}',{status:200})};
 const results=await Promise.all(Array.from({length:5},()=>images.upload(data('one'),'avatars')));
 assert.equal(new Set(results).size,1);assert.equal(posts,1);assert.equal(await images.upload(data('one'),'avatars'),results[0]);assert.equal(posts,1);
}));
test('different images have a five-second rate limit but a banner/avatar pair is allowed',async()=>fixture(async images=>{
 global.fetch=async(_u,o)=>new Response(null,{status:o.method==='HEAD'?404:200});
 await images.upload(data('one'),'avatars');await images.upload(data('two'),'avatars');await assert.rejects(images.upload(data('three'),'avatars'),/Espera/);
}));
test('referenced images are not deleted, unused images are deleted, foreign avatars are denied',async()=>fixture(async(images,service)=>{
 let deletes=0;global.fetch=async()=>{deletes++;return new Response('{}',{status:200})};service.request=async()=>true;await images.remove(url);assert.equal(deletes,0);
 service.request=async()=>false;await images.remove(url);assert.equal(deletes,1);
 await assert.rejects(images.remove(url.replace(user,'other-user')),/denegado/);
}));
test('failed cleanup stays persisted and can be retried after restart',async()=>fixture(async(images,service,dir)=>{
 global.fetch=async()=>new Response('{}',{status:503});await images.defer(url);await images.clean(false);
 const saved=JSON.parse(await fs.readFile(path.join(dir,'image-cleanup.json'),'utf8'));assert.equal(saved.length,1);assert.equal(saved[0].attempts,1);
 const restarted=new ImageStorage(service);await restarted.mutate(rows=>{rows[0].eligible=0});global.fetch=async()=>new Response('{}',{status:200});await restarted.clean(false);
 assert.equal(JSON.parse(await fs.readFile(path.join(dir,'image-cleanup.json'),'utf8')).length,0);
}));
test('storage returning an empty deletion does not silently discard cleanup',async()=>fixture(async images=>{
 global.fetch=async(_url,options)=>options.method==='DELETE'?new Response('[]',{status:200}):new Response(null,{status:200});
 await assert.rejects(images.remove(url),/no se eliminó/);
}));
test('old orphaned files are swept but active and fresh files are preserved',async()=>fixture(async(images,service)=>{
 let deletes=0;service.request=async route=>route.includes('/list/')?[{id:'one',name:'old.png',created_at:'2020-01-01'},{id:'two',name:'active.png',created_at:'2020-01-01'},{id:'three',name:'fresh.png',created_at:new Date().toISOString()}]:!route.includes('/rpc/')?false:undefined;
 service.request=async(route,options)=>route.includes('/list/')?[{id:'one',name:'old.png',created_at:'2020-01-01'},{id:'two',name:'active.png',created_at:'2020-01-01'},{id:'three',name:'fresh.png',created_at:new Date().toISOString()}]:JSON.parse(options.body).image_url.endsWith('active.png');
 global.fetch=async()=>{deletes++;return new Response('{}',{status:200})};await images.clean();assert.equal(deletes,2);
}));
